  //  Récupérer le dernier p contenu dans la div et modifier son contenu par "Dernier paragraphe"
  const div = document.querySelector('div');
  const dernierP = div.querySelector('p');
  dernierP.textContent = 'Dernier paragraphe';

  // Récupérer le lien a dans une variable a, modifier son href, son contenu HTML et ajouter un attribut title
  const lienA = document.querySelector('ul li a');
  lienA.href = 'https://www.facebook.com/';
  lienA.textContent = 'Facebook';
  lienA.setAttribute('title', 'le compte facebook');

  // Récupérer le div et lui ajouter la propriété CSS "color" avec la valeur "blue"
  div.style.color = 'blue';

  // Déclarer les variables element, texte, créer une balise li et l'affecter à element
  let element = document.createElement('li');
  let texte = 'Item 4';

  //  Ajouter le texte dans le li créé
  element.textContent = texte;

  //  Récupérer le ul présent dans le DOM et ajouter le li créé
  const ul = document.querySelector('ul');
  ul.appendChild(element);

  // Récupérer le p qui est dans la div et remplacer son contenu par "dernier Paragraphe"
  dernierP.textContent = 'dernier Paragraphe';

  //  Récupérer le div, récupérer le p dans la div et supprimer le paragraphe p
  div.removeChild(dernierP);