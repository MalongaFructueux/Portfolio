//  Fonction pour calculer le factoriel d'un nombre
function calculerFactoriel(n) {
    if (n === 0 || n === 1) {
        return 1; // Le factoriel de 0 et 1 est 1
    }
    let resultat = 1;
    for (let i = 2; i <= n; i++) {
        resultat *= i;
    }
    return resultat;
}

// Fonction pour récupérer la valeur de l'input et afficher le résultat
function afficherResultat(event) {
    event.preventDefault(); // Empêcher le rechargement de la page

    // Récupérer la valeur de l'input
    const nombre = parseInt(document.getElementById('nombre').value);

    // Vérifier si la valeur est valide
    if (isNaN(nombre) || nombre < 0) {
        document.getElementById('resultat').textContent = "Veuillez entrer un nombre valide (positif ou nul).";
        return;
    }

    const factoriel = calculerFactoriel(nombre);

    document.getElementById('resultat').textContent = `Le factoriel de ${nombre} est : ${factoriel}`;

    console.log(`Le factoriel de ${nombre} est : ${factoriel}`);
}

// Écouter l'événement de soumission du formulaire
document.getElementById('formFactoriel').addEventListener('submit', afficherResultat);