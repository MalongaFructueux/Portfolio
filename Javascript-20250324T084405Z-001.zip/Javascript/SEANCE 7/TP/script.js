// Récupérer l'écran et les boutons
const ecran = document.getElementById('ecran');
const boutons = document.querySelectorAll('.bouton');

let valeurActuelle = ''; // Stocke la valeur actuelle de l'écran
let operationEnCours = false; // Indique si une opération est en cours

// Ajouter un écouteur d'événement à chaque bouton
boutons.forEach(bouton => {
    bouton.addEventListener('click', () => {
        const valeur = bouton.getAttribute('data-valeur');

        // Gestion des boutons spéciaux
        if (valeur === 'C') {
            // Effacer tout
            valeurActuelle = '';
            operationEnCours = false;
        } else if (valeur === 'DEL') {
            // Supprimer le dernier caractère
            valeurActuelle = valeurActuelle.slice(0, -1);
        } else if (valeur === '=') {
            // Calculer le résultat
            try {
                valeurActuelle = eval(valeurActuelle).toString();
            } catch {
                valeurActuelle = 'Erreur';
            }
            operationEnCours = true;
        } else {
            // Ajouter la valeur du bouton à l'écran
            if (operationEnCours && !isNaN(valeur)) {
                valeurActuelle = '';
                operationEnCours = false;
            }
            valeurActuelle += valeur;
        }

        // Mettre à jour l'écran
        ecran.textContent = valeurActuelle || '0';
    });
});