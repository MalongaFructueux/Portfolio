let modif = document.getElementsByTagName('div')[0]

modif.innerHTML = 'Bienvenue sur ma page html';
