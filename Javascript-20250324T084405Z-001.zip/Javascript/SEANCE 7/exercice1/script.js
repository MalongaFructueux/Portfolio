   // Récupérer les éléments du DOM
   const inputCote = document.getElementById('cote');
   const checkboxPerimetre = document.getElementById('perimetre');
   const checkboxSurface = document.getElementById('surface');
   const resultatDiv = document.getElementById('resultat');

   // Fonction pour calculer et afficher les résultats
   function calculer() {
       const cote = parseFloat(inputCote.value); // Récupérer la valeur du côté

       // Vérifier si la valeur est valide
       if (isNaN(cote) || cote <= 0) {
           resultatDiv.innerHTML = "Veuillez entrer une valeur valide pour le côté.";
           return;
       }

       let resultat = "";

       // Calculer le périmètre si la checkbox est cochée
       if (checkboxPerimetre.checked) {
           const perimetre = 4 * cote;
           resultat += `<p class="perimetre">Périmètre : ${perimetre}</p>`;
       }

       // Calculer la surface si la checkbox est cochée
       if (checkboxSurface.checked) {
           const surface = cote * cote;
           resultat += `<p class="surface">Surface : ${surface}</p>`;
       }

       // Afficher le résultat
       resultatDiv.innerHTML = resultat;
   }

   // Écouter les changements sur les checkboxes et l'input
   checkboxPerimetre.addEventListener('change', calculer);
   checkboxSurface.addEventListener('change', calculer);
   inputCote.addEventListener('input', calculer);