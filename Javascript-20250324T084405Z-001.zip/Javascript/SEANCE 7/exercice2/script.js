
 const inputNom = document.getElementById('nom');
 const inputPrenom = document.getElementById('prenom');

 inputNom.style.backgroundColor = '#f0e68c'; 
 inputPrenom.style.backgroundColor = '#add8e6'; 

 // 2. Gérer le bouton "Grand ou petit"
 const bouton = document.getElementById('boutonGrandPetit');
 const resultatDiv = document.getElementById('resultat');

 bouton.addEventListener('click', function () {
     // Générer un nombre aléatoire entre 0 et 1
     const aleatoire = Math.random();

     // Afficher "Tu es grand" ou "Tu es petit" en fonction du résultat
     if (aleatoire < 0.5) {
         resultatDiv.textContent = "Tu es petit";
     } else {
         resultatDiv.textContent = "Tu es grand";
     }
 });