let maVariable1 = 15;
let maVariable2 = 20;

console.log("maVariable1 = "+maVariable1, "maVariable2 = "+maVariable2);

let inverse = maVariable1;

maVariable1 = maVariable2;
maVariable2 = inverse;

console.log("son inverse : "+ "maVariable1 = "+maVariable1, "maVariable2 = "+maVariable2);



