let nbr = parseInt(prompt('veuillez saisir un nombre'));

while (isNaN(nbr)) {
    nbr = parseInt(prompt('veuillez saisir un nombre'));
}


let i = 0;
while (i <= 10) {
    console.log(nbr + ' x ' + i + ' = ' + nbr * i);
    i++;
}


for (let i = 0; i <= 10; i++) {
    console.log(nbr + ' x ' + i + ' = ' + nbr * i);
}

