let a = 1;
let b = a + 3;
a = 3;
console.log(a, b);