// exercice 2
//Algo: Puissance
// var a,b,puissance,puissance2: entier;
//Debut
// a:= 5;
// puissance:= a**4;
// Afficher puissance;
// b:= Saisir('Entrez un nombre');
// puissance2:= b**4;
// Afficher puissance2;
// Fin

let a = 5;
let puissance = a ** 4;
console.log(puissance);


let b = prompt("Entrez un nombre");
let integerValue= parseInt(b);
let puissance2 = integerValue ** 4;
alert(puissance2);
console.log(integerValue);