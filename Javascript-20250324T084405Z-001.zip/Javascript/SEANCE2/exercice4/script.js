let age = parseInt(prompt('veuillez votre age'));

while (isNaN(age)) {
    age = parseInt(prompt('veuillez saisir un nombre'));
}


 if (age>0 && age < 12 ) {
    document.write(' <br> vous êtes un enfant');
 } else if (age >= 12 && age <= 17) {
   document.write(' <br> vous êtes  adolescent');
 } else if (age >= 18 && age <= 120) {
   document.write(' <br> vous êtes  adulte');
 } 