let nbre = Math.floor(Math.random() * 100) + 1; // Génère un nombre aléatoire entre 1 et 100
let vies = 7; // Nombre de vies disponibles
let valeur;

// Fonction pour demander et valider l'entrée de l'utilisateur
function demanderNombre(message) {
  let saisie;
  do {
    saisie = prompt(message);
    if (saisie === null) {
      // Gestion de l'annulation
      alert("Saisie annulée. Merci d'avoir joué !");
      return null; // Sort de la fonction
    }
    saisie = parseInt(saisie);
    // verifie que la saisie contient uniquement des chiffres.
     if (!/^\d+$/.test(saisie)) {
      alert("Erreur : Veuillez entrer un nombre entier valide !");
    } else {
      return parseInt(saisie); // Convertir en entier une fois validé
    }
  } while (isNaN(saisie)); // Continue tant que la saisie n'est pas valide
  return saisie;
}

// Boucle principale du jeu
while (vies > 0) {
  valeur = demanderNombre(`Vous avez ${vies} vies restantes. Devinez le nombre entre 1 et 100 :`); //mon selecteur  ${vies}
  if (valeur === null) {
    // Si l'utilisateur annulearrêter le jeu
    break;
  }

  if (valeur < nbre) {
    alert("C'est plus !");
  } else if (valeur > nbre) {
    alert("C'est moins !");
  } else {
    const rejouer = confirm("Bravo, vous avez trouvé le bon nombre ! Voulez-vous rejouer ?");
    if (rejouer) {
      location.reload(); // Recharge la page pour recommencer
    } else {
      alert("Merci d'avoir joué !");
    }
    break;
  }

  vies--; // Réduit le nombre de vies après chaque tentative
}

// Si l'utilisateur n'a plus de vies
if (vies === 0) {
  const rejouer = confirm(`Vous avez perdu ! Le nombre était ${nbre}. Voulez-vous rejouer ?`); //mon selecteur  ${nbre}
  if (rejouer) {
    location.reload(); // Recharge la page pour recommencer
  } else {
    alert("Merci d'avoir joué !");
  }
}
