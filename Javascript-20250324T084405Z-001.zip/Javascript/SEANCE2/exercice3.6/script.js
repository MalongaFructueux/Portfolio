// Algo: Calcul du Prix
// var prixHT, var tva, var prixTTC, nbreArticles : entier
// debut
// fonction demanderEntier(message: chaine de caractere)
//  var valeur: entier
//  faire
//  valeur = demanderEntier(message)
//  si valeur = NaN alors
//  afficher("Erreur : veuillez entrer un nombre entier valide.")
//  fin si
//  tant que valeur = NaN
//     retourner valeur
// fin fonction
// saisir prixHT
// saisir tva
// saisir nbreArticles
// prixTTC = prixHT + prixHT * tva / 100
// ecrire prixTTC
// fin




//fonction pour demander un entier à l'utilisateur
function demanderEntier(message) {
    let valeur;
    do {
        valeur = parseInt(prompt(message));
        if (isNaN(valeur)) {
            alert("Erreur : veuillez entrer un nombre entier valide.");
        }
    } while (isNaN(valeur)); 
    return valeur;
}


let prixHT = demanderEntier("Veuillez saisir le prix HT");
let tva = demanderEntier("Veuillez saisir la TVA");
let nbreArticles = demanderEntier("Veuillez saisir le nombre d'articles");

let prixTTC = prixHT + (prixHT * tva / 100);
let prixTotal = prixTTC * nbreArticles;


document.write("Le prix TTC est de " + prixTTC + " €");
document.write("<br> Le prix total est de " + prixTotal + " €");
