// Algo: Inverse des variables
// var a, var b, var c: entier
// debut
// var a:= entier
// var b:= entier
// var c:= a
// a:= b
// b:= a
// fin


let a = 5;
let b = 10;

let c = a;
a = b;
b = c;

console.log(a, b);