let a = 5;

let b = 3;

let c = a + b;

a = 2;

c = b - a;

console.log(a, b, c);