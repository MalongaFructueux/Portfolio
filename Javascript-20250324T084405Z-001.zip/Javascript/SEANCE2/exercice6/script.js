function carre(nombre) {
    return nombre * nombre;
}

console.log(carre(5)); 
console.log(carre(18)); 
