let votreNom = "Malonga";
let votrePrenom = "Fructueux";
let votreAge = 21+"ans";

console.log("Nom :"+votreNom,"Prenom :"+votrePrenom,"Age :"+votreAge);