let a = 5;
let b = a + 4;
a = a + 1;
b = a - 4;

console.log(a, b);