let val = 231;
let double = val * 2;

document.write('<br> val '+val);
document.write('<br> double '+ double);
