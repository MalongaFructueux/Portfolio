let caractere = "7";


let nombreEval = eval(caractere);
console.log(nombreEval, typeof nombreEval); 


let entier = parseInt(nombreEval / 2);
console.log(entier, typeof entier); 

let flottant = parseFloat(nombreEval / 2);
console.log(flottant, typeof flottant); 

