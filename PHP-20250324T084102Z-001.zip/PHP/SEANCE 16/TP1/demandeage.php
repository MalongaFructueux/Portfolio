<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $age = $_POST['age'] ?? '';

    if (empty($age)) {
        echo "<p>Veuillez entrer votre âge.</p>";
    } elseif (!is_numeric($age) || $age < 1 || $age > 120) {
        echo "<p>Veuillez entrer un âge valide (entre 1 et 120).</p>";
    } else {
        $age = intval($age);
        if ($age < 6) {
            $reward = "Bébé";
        } elseif ($age < 18) {
            $reward = "Mineur";
        } elseif ($age < 25) {
            $reward = "Ado";
        } else {
            $reward = "Adulte";
        }
        echo "<p>Vous êtes un(e) $reward.</p>";
        echo "<button onclick=\"window.location.href='index.html'\">Retour</button>";
        exit;
    }
}
?>