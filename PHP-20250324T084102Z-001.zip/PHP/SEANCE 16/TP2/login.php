<?php
session_start();

// Informations de connexion (simulées)
$valid_login = "user";
$valid_password = "password";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $login = $_POST['login'];
    $password = $_POST['password'];

    if ($login === $valid_login && $password === $valid_password) {
        $_SESSION['logged_in'] = true;
        $_SESSION['login'] = $login;
        $_SESSION['secret_price'] = rand(1, 100); // Prix aléatoire entre 1 et 100
        header("Location: jeu.php");
        exit;
    } else {
        echo "<p>Login ou mot de passe incorrect.</p>";
    }
}
?>