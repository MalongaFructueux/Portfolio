<?php
session_start();

if (!isset($_SESSION['logged_in'])) {
    header("Location: index.html");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Le Juste Prix</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Bienvenue, <?php echo $_SESSION['login']; ?> !</h2>
        <p>Devinez le prix de l'article (entre 1 et 100) :</p>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guess'])) {
            $guess = intval($_POST['guess']);
            $secret_price = $_SESSION['secret_price'];

            if ($guess < $secret_price) {
                echo "<p>C'est plus !</p>";
            } elseif ($guess > $secret_price) {
                echo "<p>C'est moins !</p>";
            } else {
                echo "<p>Bravo, vous avez trouvé le juste prix !</p>";
                unset($_SESSION['secret_price']); // Réinitialiser le prix
            }
        }
        ?>
        <form method="POST" action="">
            <input type="number" name="guess" min="1" max="100" required>
            <button type="submit">Deviner</button>
        </form>
        <br>
        <a href="?logout=true">Se déconnecter</a>
    </div>
</body>
</html>