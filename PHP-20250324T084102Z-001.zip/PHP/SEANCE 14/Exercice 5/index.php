<?php
function inverse($nombre) {
    // Vérifier si le nombre est zéro pour éviter la division par zéro
    if ($nombre == 0) {
        return "Erreur : division par zéro impossible.";
    }
    return 1 / $nombre;
}

// Tests avec 15, 0 et 5
$tests = [15, 0, 5];

foreach ($tests as $test) {
    echo "L'inverse de $test est : " . inverse($test) . "\n";
}
?>
