<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau des nombres</title>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
            text-align: center;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<table>
    <tr>
        <th>Entiers</th>
        <th>Carrés</th>
        <th>Racines Carrées</th>
    </tr>
    <tr>
        <?php
        // Affichage des 10 premiers entiers avec une boucle for
        for ($i = 1; $i <= 10; $i++) {
            echo "<td>$i</td>";
        }
        ?>
    </tr>
    <tr>
        <?php
        // Affichage des carrés avec une boucle while
        $j = 1;
        while ($j <= 10) {
            echo "<td>" . ($j * $j) . "</td>";
            $j++;
        }
        ?>
    </tr>
    <tr>
        <?php
        // Affichage des racines carrées avec une boucle do..while
        $k = 1;
        do {
            echo "<td>" . number_format(sqrt($k), 2) . "</td>";
            $k++;
        } while ($k <= 10);
        ?>
    </tr>
</table>

</body>
</html>
