<?php
// Définition du tableau numéroté
$noms = ["Romain", "Ruddy", "Rémi", "Randy"];

// Affichage des éléments du tableau dans une liste à puces
echo "<h3>Liste des prénoms :</h3>";
echo "<ul>";
foreach ($noms as $nom) {
    echo "<li>$nom</li>";
}
echo "</ul>";

// Affichage de la taille du tableau
echo "<p>La taille du tableau est : " . count($noms) . "</p>";

// Création d'un tableau associatif
$personne = [
    "nom" => "Randy",
    "profession" => "formateur"
];

// Vérification que "Randy" appartient au tableau
if (in_array("Randy", $personne)) {
    echo "<p>Randy appartient au tableau associatif.</p>";
} else {
    echo "<p>Randy n'appartient pas au tableau associatif.</p>";
}

// Vérification de l'existence de la clé "profession"
if (array_key_exists("profession", $personne)) {
    echo "<p>La clé 'profession' existe dans le tableau.</p>";
} else {
    echo "<p>La clé 'profession' n'existe pas dans le tableau.</p>";
}

// Affichage du tableau associatif avec foreach
echo "<h3>Informations de la personne :</h3>";
echo "<ul>";
foreach ($personne as $cle => $valeur) {
    echo "<li>$cle : $valeur</li>";
}
echo "</ul>";

// Remplacement de "formateur" par "formateur informatique"
$personne["profession"] = "formateur informatique";

// Création d'un deuxième tableau associatif
$details = [
    "prenom" => "Randy",
    "age" => 38,
    "nom" => "Yele"
];

// Fusion des deux tableaux
$infoComplete = array_merge($personne, $details);

// Affichage des informations fusionnées sous forme de phrase
echo "<p>{$infoComplete['prenom']} {$infoComplete['nom']} a {$infoComplete['age']} ans et travaille en tant que {$infoComplete['profession']}.</p>";
?>
