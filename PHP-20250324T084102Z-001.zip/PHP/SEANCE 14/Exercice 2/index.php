<?php
$nom1 = 'Alain';
$age1 = 10;
$estUnHomme1 = true;

echo ucfirst($nom1) . " a $age1 ans et c’est " . ($estUnHomme1 ? "un homme" : "une femme") . ".\n";

$nom2 = 'Jeanne';
$age2 = 15;
$estUnHomme2 = false;

echo ucfirst($nom2) . " a $age2 ans et c’est " . ($estUnHomme2 ? "un homme" : "une femme") . ".\n";
?>
