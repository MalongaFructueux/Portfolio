<?php
function supprimerVoyelles($mot) {
    // Définition des voyelles en minuscules et majuscules
    $voyelles = ['a', 'e', 'i', 'o', 'u', 'y', 'A', 'E', 'I', 'O', 'U', 'Y'];
    
    // Remplacement des voyelles par une chaîne vide
    return str_replace($voyelles, '', $mot);
}

// Test avec le mot "Bonjour"
$motTest = "Bonjour";
$resultat = supprimerVoyelles($motTest);

// Affichage du résultat
echo "Mot original : $motTest\n";
echo "Mot sans voyelles : $resultat\n";
?>
