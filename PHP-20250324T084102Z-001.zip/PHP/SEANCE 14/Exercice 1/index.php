<?php
// Déclaration des variables
$nom = "Randy";
$nombre1 = 7;
$nombre2 = 4;

// Affichage des variables
echo "Les variables nom, nombre1 et nombre2 ont pour valeurs respectives $nom, $nombre1 et $nombre2.<br>";

// Calculs et affichage
echo "L’addition de nombre1 et nombre2 est : " . ($nombre1 + $nombre2) . "<br>";
echo "La multiplication de nombre1 et nombre2 est : " . ($nombre1 * $nombre2) . "<br>";
echo "La soustraction de nombre1 et nombre2 est : " . ($nombre1 - $nombre2) . "<br>";
echo "La division de nombre1 et nombre2 est : " . ($nombre1 / $nombre2) . "<br>";
echo "Le modulo de nombre1 et nombre2 est : " . ($nombre1 % $nombre2) . "<br>";
echo "La puissance de nombre1 et nombre2 est : " . pow($nombre1, $nombre2) . "<br>";

// Déclaration d'un tableau et d'une variable booléenne
$tableau = [18, 14, 27, 5];
$monBooleen = false;

// Affichage des types
echo "Le type de la variable tableau est : " . gettype($tableau) . "<br>";
echo "Le type de la variable monBooleen est : " . gettype($monBooleen) . "<br>";

// Déclaration d'une constante
define("CONSTANTE", "Je suis une constante");

// Affichage de la constante
echo "La valeur de la constante est : " . CONSTANTE . "<br>";
?>
