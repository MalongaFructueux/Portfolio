<?php
// Démarre une session PHP pour gérer les données de session
session_start();

// Définit le type de contenu de la réponse comme JSON
header('Content-Type: application/json');

// Informations de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

// Crée une connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifie si la connexion à la base de données a échoué
if ($conn->connect_error) {
    // Retourne une réponse JSON en cas d'échec de la connexion
    echo json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]);
    exit(); // Arrête l'exécution du script
}

// Vérifie si l'utilisateur est connecté en vérifiant les variables de session
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    // Retourne une réponse JSON si l'utilisateur n'est pas connecté
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit(); // Arrête l'exécution du script
}

// Récupère les données JSON envoyées dans le corps de la requête
$data = json_decode(file_get_contents('php://input'), true);

// Nettoie et sécurise les données reçues
$title = htmlspecialchars($data['title']); // Nettoie le titre de l'article
$content = htmlspecialchars($data['content']); // Nettoie le contenu de l'article
$user_id = $_SESSION['user_id']; // Récupère l'ID de l'utilisateur à partir de la session

// Requête SQL pour insérer un nouvel article dans la base de données
$sql = "INSERT INTO articles (user_id, titre_Article, contenu_Article, date_Article) 
        VALUES (?, ?, ?, NOW())"; // NOW() insère la date et l'heure actuelles

// Prépare la requête SQL pour éviter les injections SQL
$stmt = $conn->prepare($sql);

// Lie les paramètres à la requête préparée
$stmt->bind_param("iss", $user_id, $title, $content); // "iss" correspond aux types de données (integer, string, string)

// Exécute la requête préparée
if ($stmt->execute()) {
    // Retourne une réponse JSON en cas de succès
    echo json_encode(['success' => true]);
} else {
    // Retourne une réponse JSON en cas d'échec de l'exécution de la requête
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Ferme la requête préparée
$stmt->close();

// Ferme la connexion à la base de données
$conn->close();
?>