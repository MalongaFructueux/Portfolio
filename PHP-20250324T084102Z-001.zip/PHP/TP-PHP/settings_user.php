<?php
$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';

// Traitement des requêtes POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Changer la langue
    if (isset($_POST['language']) && isset($_POST['save_changes'])) {
        $language = $_POST['language'];
        if (in_array($language, ['fr', 'en'])) {
            $message = "Langue sélectionnée : " . ($language === 'fr' ? 'Français' : 'English') . " (appliquée via JavaScript).";
        } else {
            $message = "Langue non valide.";
        }
    }

    // Supprimer le compte
    if (isset($_POST['username']) && isset($_POST['delete_account'])) {
        $username = $_POST['username'];

        // Vérifier si l'utilisateur existe
        $check_sql = "SELECT user_id FROM users WHERE username = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $user_id = $row['user_id'];

            // Supprimer de active_sessions
            $delete_session_sql = "DELETE FROM active_sessions WHERE user_id = ?";
            $session_stmt = $conn->prepare($delete_session_sql);
            $session_stmt->bind_param("i", $user_id);
            $session_stmt->execute();
            $session_stmt->close();

            // Supprimer de users
            $delete_user_sql = "DELETE FROM users WHERE user_id = ?";
            $user_stmt = $conn->prepare($delete_user_sql);
            $user_stmt->bind_param("i", $user_id);
            $user_stmt->execute();
            $affected_rows = $user_stmt->affected_rows;
            $user_stmt->close();

            if ($affected_rows > 0) {
                $message = "Compte '$username' supprimé avec succès.";
            } else {
                $message = "Erreur lors de la suppression du compte.";
            }
        } else {
            $message = "Utilisateur '$username' non trouvé.";
        }
        $check_stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paramètres Utilisateur</title>
    <link rel="stylesheet" href="settings_user.css">
</head>
<body>
<div id="settings-page"> <!-- Encapsulation du contenu -->
        <h2 data-translate="Settings">Paramètres</h2>
        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'succès') !== false ? 'success' : 'error'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </p>
        <?php endif; ?>

        <!-- Formulaire pour changer la langue -->
        <form method="POST" id="language-form">
            <label for="language" data-translate="Language">Langue :</label>
            <select id="language" name="language">
                <option value="fr">Français</option>
                <option value="en">English</option>
            </select>
            <button type="submit" name="save_changes" value="yes" data-translate="Save">Enregistrer les modifications</button>
        </form>

        <!-- Formulaire pour supprimer un compte -->
        <form method="POST" onsubmit="return confirm(getConfirmationMessage());">
            <label for="username" data-translate="Username">Nom d'utilisateur :</label>
            <input type="text" id="username" name="username" required placeholder="Entrez votre nom d'utilisateur">
            <button type="submit" name="delete_account" value="yes" data-translate="Delete Account">Supprimer le compte</button>
        </form>

        <!-- Boutons de navigation -->
        <div class="navigation-buttons">
            <button onclick="history.back()" data-translate="Back">Retour à la page précédente</button>
            <a href="login.php" data-translate="Login">Se connecter</a> | 
            <a href="register.php" data-translate="Register">S'inscrire</a>
        </div>
    </div>

    <script src="settings.js"></script>
    <script>
        // Appliquer la langue au chargement
        document.addEventListener('DOMContentLoaded', function() {
            const savedLanguage = localStorage.getItem('language') || 'fr';
            document.getElementById('language').value = savedLanguage;
        });

        // Mettre à jour la langue après soumission
        <?php if (isset($_POST['language']) && in_array($_POST['language'], ['fr', 'en'])): ?>
            localStorage.setItem('language', '<?php echo $_POST['language']; ?>');
            applySettings('<?php echo $_POST['language']; ?>', localStorage.getItem('theme') || 'light');
        <?php endif; ?>

        function getConfirmationMessage() {
            const language = localStorage.getItem('language') || 'fr';
            const translations = getTranslations(language);
            return translations['Are you sure you want to delete your account? This action cannot be undone.'];
        }
    </script>
</body>
</html>