<?php
// Démarre une session PHP pour gérer les données de session
session_start();

// Vérifie si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    // Redirige vers la page de connexion si l'utilisateur n'est pas administrateur ou non connecté
    header('Location: login.php');
    exit(); // Arrête l'exécution du script
}

// Log pour confirmer la session (utile pour le débogage)
error_log("Admin Panel - Session ID: " . session_id());
error_log("Admin Panel - is_admin: " . var_export($_SESSION['is_admin'], true));

// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); // Affiche un message d'erreur et arrête le script
}

// Requête SQL pour récupérer les articles triés par date décroissante
$articles_sql = "SELECT id_Article, titre_Article, date_Article FROM articles ORDER BY date_Article DESC";
$articles_result = $conn->query($articles_sql);

// Requête SQL pour récupérer les commentaires triés par date décroissante
$comments_sql = "SELECT id_Comment, auteur_Comment, contenu_Comment, date_Comment FROM comments ORDER BY date_Comment DESC";
$comments_result = $conn->query($comments_sql); // Correction ici : $comments_sql au lieu de $sql_comments
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Admin</title>
    <link rel="stylesheet" href="styles.css"> <!-- Lien vers la feuille de style CSS -->
</head>
<body>
    <header>
        <div class="nav-container">
            <h1 data-translate="Administration du Blog">Administration du Blog</h1>
            <nav>
                <ul>
                    <!-- Liens de navigation -->
                    <li><a href="admin_panel.php">Tableau de bord</a></li>
                    <li><a href="index.php">Articles</a></li>
                    <li><a href="comments.php">Commentaires</a></li>
                    <li><a href="settings.php">Paramètres</a></li>
                    <li><a href="logout.php" data-translate="Se déconnecter">Se déconnecter</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <!-- Section des statistiques -->
        <div class="stats-container">
            <div class="stat">
                <p class="stat-name" data-translate="Connected Users">Personnes connectées</p>
                <p class="stat-number" id="connected-count">0</p>
            </div>
            <div class="stat">
                <p class="stat-name" data-translate="Registered Users">Inscrits</p>
                <p class="stat-number" id="users-count">0</p>
            </div>
            <div class="stat">
                <p class="stat-name" data-translate="Published Articles">Articles publiés</p>
                <p class="stat-number" id="articles-count">0</p>
            </div>
            <div class="stat">
                <p class="stat-name" data-translate="Comments">Commentaires</p>
                <p class="stat-number" id="comments-count">0</p>
            </div>
        </div>

        <!-- Section de gestion des articles -->
        <div class="manage-articles">
            <h1>Gérer les articles</h1>
            <label for="title">Titre de l'article:</label>
            <input type="text" id="title" placeholder="Entrez le titre de l'article">
            <label for="content">Description de l'article:</label>
            <textarea id="content" rows="4" placeholder="Entrez la description de l'article"></textarea>
            <button id="publish-article">Publier l'article</button>

            <!-- Formulaire de modification d'article (caché par défaut) -->
            <div id="edit-article-form-container" style="display: none;">
                <h2>Modifier l'article</h2>
                <form id="edit-article-form">
                    <input type="hidden" id="edit-article-id" name="id">
                    <label for="edit-title">Titre de l'article:</label>
                    <input type="text" id="edit-title" name="titre" placeholder="Entrez le titre de l'article">
                    <label for="edit-content">Description de l'article:</label>
                    <textarea id="edit-content" name="contenu" rows="4" placeholder="Entrez la description de l'article"></textarea>
                    <button type="button" onclick="saveEditedArticle()">Enregistrer les modifications</button>
                    <button type="button" onclick="cancelEdit()">Annuler</button>
                </form>
            </div>

            <!-- Liste des articles -->
            <h2>Liste des articles</h2>
            <div class="articles-table">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Titre</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="articlesList">
                        <?php while ($article = $articles_result->fetch_assoc()): ?>
                            <tr data-id="<?php echo $article['id_Article']; ?>">
                                <td><?php echo htmlspecialchars($article['id_Article']); ?></td>
                                <td><?php echo htmlspecialchars($article['titre_Article']); ?></td>
                                <td><?php echo htmlspecialchars($article['date_Article']); ?></td>
                                <td>
                                    <button onclick="editArticle(<?php echo $article['id_Article']; ?>)">Modifier</button>
                                    <button onclick="deleteArticle(<?php echo $article['id_Article']; ?>)">Supprimer</button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Section de gestion des commentaires -->
        <div class="manage-comments">
            <h2>Gérer les commentaires</h2>
            <div class="comments-table">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Auteur</th>
                            <th>Commentaire</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="commentsList">
                        <?php while ($comment = $comments_result->fetch_assoc()): ?>
                            <tr data-id="<?php echo $comment['id_Comment']; ?>">
                                <td><?php echo htmlspecialchars($comment['id_Comment']); ?></td>
                                <td><?php echo htmlspecialchars($comment['auteur_Comment']); ?></td>
                                <td><?php echo htmlspecialchars($comment['contenu_Comment']); ?></td>
                                <td><?php echo htmlspecialchars($comment['date_Comment']); ?></td>
                                <td>
                                    <button onclick="editComment(<?php echo $comment['id_Comment']; ?>)">Modifier</button>
                                    <button onclick="deleteComment(<?php echo $comment['id_Comment']; ?>)">Supprimer</button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Section des paramètres -->
        <div class="settings">
            <h2>Paramètres</h2>
            <label for="blog-title">Titre du blog:</label>
            <input type="text" id="blog-title" placeholder="Entrez le titre du blog">
            <label for="blog-description">Description du blog:</label>
            <textarea id="blog-description" rows="4" placeholder="Entrez la description du blog"></textarea>
            <button class="save-btn" onclick="saveSettings()">Enregistrer les paramètres</button>
        </div>
    </main>

    <footer>
        <p>© 2025 Malonga Fructueux, Tous droits réservés</p>
    </footer>
    <script src="settings.js"></script> <!-- Lien vers le fichier JavaScript pour les paramètres -->
    <script>
        // Fonction pour mettre à jour les statistiques
        function updateStats() {
            console.log('Début updateStats : ' + new Date().toISOString());
            fetch('get_stats.php', {
                method: 'GET',
                headers: { 'Cache-Control': 'no-cache' },
                credentials: 'include' // Inclut les cookies de session
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erreur réseau : ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                console.log('Stats reçues :', data);
                if (!data.error) {
                    document.getElementById('connected-count').textContent = data.connected;
                    document.getElementById('users-count').textContent = data.users;
                    document.getElementById('articles-count').textContent = data.articles;
                    document.getElementById('comments-count').textContent = data.comments;
                } else {
                    console.error('Erreur dans les données :', data.error);
                }
            })
            .catch(error => console.error('Erreur fetch :', error));
        }

        // Fonction pour enregistrer les paramètres
        function saveSettings() {
            const blogTitle = document.getElementById('blog-title').value;
            const blogDescription = document.getElementById('blog-description').value;

            if (blogTitle === '' || blogDescription === '') {
                alert('Veuillez remplir tous les champs.');
                return;
            }

            fetch('save_settings.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title: blogTitle, description: blogDescription })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Paramètres enregistrés avec succès.');
                } else {
                    alert('Erreur lors de l\'enregistrement des paramètres: ' + data.error);
                }
            })
            .catch(error => console.error('Erreur lors de l\'enregistrement des paramètres:', error));
        }

        // Gestion de la publication d'un nouvel article
        document.getElementById('publish-article').addEventListener('click', function() {
            const title = document.getElementById('title').value;
            const content = document.getElementById('content').value;

            if (!title || !content) {
                alert('Veuillez remplir le titre et la description.');
                return;
            }

            fetch('publish_article.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ titre: title, contenu: content, user_id: <?php echo $_SESSION['user_id']; ?> })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const tbody = document.getElementById('articlesList');
                    const newRow = document.createElement('tr');
                    newRow.setAttribute('data-id', data.id);
                    newRow.innerHTML = `
                        <td>${data.id}</td>
                        <td>${title}</td>
                        <td>${new Date().toISOString().slice(0, 19).replace('T', ' ')}</td>
                        <td>
                            <button onclick="editArticle(${data.id})">Modifier</button>
                            <button onclick="deleteArticle(${data.id})">Supprimer</button>
                        </td>
                    `;
                    tbody.insertBefore(newRow, tbody.firstChild);
                    document.getElementById('title').value = '';
                    document.getElementById('content').value = '';
                    alert('Article publié avec succès.');
                    updateStats();
                } else {
                    alert('Erreur : ' + data.error);
                }
            })
            .catch(error => console.error('Erreur:', error));
        });

        // Fonction pour éditer un article
        function editArticle(articleId) {
            const row = document.querySelector(`#articlesList tr[data-id="${articleId}"]`);
            const title = row.cells[1].textContent;
            document.getElementById('edit-article-id').value = articleId;
            document.getElementById('edit-title').value = title;
            document.getElementById('edit-content').value = "";
            document.getElementById('edit-article-form-container').style.display = 'block';
        }

        // Fonction pour sauvegarder les modifications d'un article
        function saveEditedArticle() {
            const id = document.getElementById('edit-article-id').value;
            const title = document.getElementById('edit-title').value;
            const content = document.getElementById('edit-content').value;

            fetch('edit_article.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id, titre: title, contenu: content })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const row = document.querySelector(`#articlesList tr[data-id="${id}"]`);
                    row.cells[1].textContent = title;
                    alert('Article modifié avec succès.');
                    cancelEdit();
                    updateStats();
                } else {
                    alert('Erreur : ' + data.error);
                }
            })
            .catch(error => console.error('Erreur:', error));
        }

        // Fonction pour annuler l'édition d'un article
        function cancelEdit() {
            document.getElementById('edit-article-form-container').style.display = 'none';
        }

        // Fonction pour supprimer un article
        function deleteArticle(articleId) {
            if (confirm('Voulez-vous vraiment supprimer cet article ?')) {
                fetch('delete_article.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: articleId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector(`#articlesList tr[data-id="${articleId}"]`).remove();
                        alert('Article supprimé avec succès.');
                        updateStats();
                    } else {
                        alert('Erreur : ' + data.error);
                    }
                })
                .catch(error => console.error('Erreur:', error));
            }
        }

        // Fonction pour éditer un commentaire
        function editComment(commentId) {
            const row = document.querySelector(`#commentsList tr[data-id="${commentId}"]`);
            const author = row.cells[1].textContent;
            const content = prompt("Nouveau contenu du commentaire :", row.cells[2].textContent);

            if (content !== null) {
                fetch('edit_comment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: commentId, auteur: author, contenu: content })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        row.cells[2].textContent = content;
                        alert('Commentaire modifié avec succès.');
                        updateStats();
                    } else {
                        alert('Erreur : ' + data.error);
                    }
                })
                .catch(error => console.error('Erreur:', error));
            }
        }

        // Fonction pour supprimer un commentaire
        function deleteComment(commentId) {
            if (confirm('Voulez-vous vraiment supprimer ce commentaire ?')) {
                fetch('delete_comment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: commentId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector(`#commentsList tr[data-id="${commentId}"]`).remove();
                        alert('Commentaire supprimé avec succès.');
                        updateStats();
                    } else {
                        alert('Erreur : ' + data.error);
                    }
                })
                .catch(error => console.error('Erreur:', error));
            }
        }

        // Heartbeat pour maintenir la session admin active
        function sendHeartbeat() {
            fetch('heartbeat.php', {
                method: 'GET',
                credentials: 'include'
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    console.warn('Heartbeat échoué');
                }
            })
            .catch(error => console.error('Erreur heartbeat :', error));
        }

        // Lancer les mises à jour
        updateStats();
        setInterval(updateStats, 5000); // Mise à jour toutes les 5 secondes
        setInterval(sendHeartbeat, 10000); // Heartbeat toutes les 10 secondes
    </script>
</body>
</html>

<?php
// Ferme la connexion à la base de données
$conn->close();
?>