// Fonction pour charger les articles depuis le serveur et les afficher dans le DOM
function loadArticles() {
    fetch('load_articles.php') 
        .then(response => response.json()) // Convertir la réponse en JSON
        .then(articles => {
            const articlesList = document.getElementById('articlesList'); 
            articlesList.innerHTML = ''; // Vider le contenu précédent
            articles.forEach(article => { // Pour chaque article récupéré
                const row = document.createElement('tr'); 
                row.innerHTML = ` // Définir le contenu de la ligne
                    <td>${article.id_Article}</td> // ID de l'article
                    <td>${article.titre_Article}</td> // Titre de l'article
                    <td>${article.date_Article}</td> // Date de l'article
                    <td>
                        <button class="edit-btn" data-id="${article.id_Article}">Modifier</button> // Bouton pour éditer l'article
                        <button class="delete-btn" data-id="${article.id_Article}">Supprimer</button> // Bouton pour supprimer l'article
                    </td>
                `;
                articlesList.appendChild(row); // Ajouter la ligne au tableau
            });
        })
        .catch(error => console.error('Erreur lors de la récupération des articles:', error)); 
}

// Écouter le clic sur le bouton "Publier l'article"
document.getElementById('publish-article').addEventListener('click', function() {
    const titre = document.getElementById('title').value; 
    const contenu = document.getElementById('content').value;

    if (titre === '' || contenu === '') { 
        alert('Veuillez remplir tous les champs.'); 
        return;
    }

    fetch('save_article.php', { 
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ titre, contenu }) // Envoyer les données sous forme de JSON
    })
    .then(response => response.json()) 
    .then(data => {
        if (data.success) { 
            alert('Article publié avec succès.'); 
            loadArticles(); 
            document.getElementById('title').value = '';
            document.getElementById('content').value = ''; 
        } else {
            alert('Erreur lors de la publication de l\'article.'); 
        }
    })
    .catch(error => console.error('Erreur:', error)); 
});

// Écouter les clics sur la page
document.addEventListener('click', function(event) {
   
    if (event.target.classList.contains('delete-btn')) {
        const articleId = event.target.getAttribute('data-id'); 
        if (confirm('Êtes-vous sûr de vouloir supprimer cet article ?')) {
            fetch('delete_article.php', { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: articleId }) // Envoyer l'ID de l'article à supprimer
            })
            .then(response => response.json()) 
            .then(data => {
                if (data.success) { 
                    alert('Article supprimé avec succès.'); 
                    event.target.closest('tr').remove(); 
                } else {
                    alert('Erreur lors de la suppression de l\'article.'); 
                }
            })
            .catch(error => console.error('Erreur:', error)); 
        }
    }

    // Si le clic est sur un bouton "Modifier"
    if (event.target.classList.contains('edit-btn')) {
        const articleId = event.target.getAttribute('data-id'); 
        fetch(`get_article.php?id=${articleId}`)
            .then(response => response.json()) 
            .then(article => {
                const row = event.target.closest('tr'); 
                row.innerHTML = ` // Remplacer le contenu de la ligne par un formulaire d'édition
                    <td>${article.id_Article}</td>
                    <td><input type="text" class="edit-title" value="${article.titre_Article}"></td>
                    <td><textarea class="edit-content">${article.contenu_Article}</textarea></td>
                    <td>
                        <button class="save-btn" data-id="${article.id_Article}">Enregistrer</button>
                        <button class="cancel-btn" data-id="${article.id_Article}">Annuler</button>
                    </td>
                `;
            })
            .catch(error => console.error('Erreur:', error)); 
    }

    // Si le clic est sur un bouton "Enregistrer"
    if (event.target.classList.contains('save-btn')) {
        const articleId = event.target.getAttribute('data-id'); 
        const titre = event.target.closest('tr').querySelector('.edit-title').value; 
        const contenu = event.target.closest('tr').querySelector('.edit-content').value; 

        fetch('edit_article.php', { 
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: articleId, titre, contenu }) 
        })
        .then(response => response.json()) 
        .then(data => {
            if (data.success) { 
                alert('Article modifié avec succès.'); 
                loadArticles(); 
            } else {
                alert('Erreur lors de la modification de l\'article.'); 
            }
        })
        .catch(error => console.error('Erreur:', error)); 
    }

    // Si le clic est sur un bouton "Annuler"
    if (event.target.classList.contains('cancel-btn')) {
        loadArticles();
    }
});

// Attendre que le DOM soit chargé
document.addEventListener('DOMContentLoaded', function() {
    loadArticles(); // Charger la liste des articles
});

// Charger les commentaires
function loadComments() {
    fetch('load_comments.php')
        .then(response => response.json())
        .then(comments => {
            const commentsList = document.getElementById('commentsList');
            commentsList.innerHTML = '';
            comments.forEach(comment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${comment.id}</td>
                    <td>${comment.auteur}</td>
                    <td>${comment.commentaire}</td>
                    <td>${comment.date_commentaire}</td>
                    <td>
                        <button class="edit-comment-btn" data-id="${comment.id}">Modifier</button>
                        <button class="delete-comment-btn" data-id="${comment.id}">Supprimer</button>
                    </td>
                `;
                commentsList.appendChild(row);
            });
        })
        .catch(error => console.error('Erreur lors de la récupération des commentaires:', error));
}

// Supprimer un commentaire
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('delete-comment-btn')) {
        const commentId = event.target.getAttribute('data-id');
        if (confirm('Êtes-vous sûr de vouloir supprimer ce commentaire ?')) {
            fetch('delete_comment_admin.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: commentId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Commentaire supprimé avec succès.');
                    loadComments();
                } else {
                    alert('Erreur lors de la suppression du commentaire.');
                }
            })
            .catch(error => console.error('Erreur:', error));
        }
    }
});

// Modifier un commentaire
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('edit-comment-btn')) {
        const commentId = event.target.getAttribute('data-id');
        fetch(`get_comment.php?id=${commentId}`)
            .then(response => response.json())
            .then(comment => {
                const row = event.target.closest('tr');
                row.innerHTML = `
                    <td>${comment.id}</td>
                    <td>${comment.auteur}</td>
                    <td><textarea class="edit-comment-content">${comment.commentaire}</textarea></td>
                    <td>${comment.date_commentaire}</td>
                    <td>
                        <button class="save-comment-btn" data-id="${comment.id}">Enregistrer</button>
                        <button class="cancel-comment-btn" data-id="${comment.id}">Annuler</button>
                    </td>
                `;
            })
            .catch(error => console.error('Erreur:', error));
    }

    if (event.target.classList.contains('save-comment-btn')) {
        const commentId = event.target.getAttribute('data-id');
        const commentaire = event.target.closest('tr').querySelector('.edit-comment-content').value;

        fetch('edit_comment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: commentId, commentaire })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Commentaire modifié avec succès.');
                loadComments();
            } else {
                alert('Erreur lors de la modification du commentaire.');
            }
        })
        .catch(error => console.error('Erreur:', error));
    }

    if (event.target.classList.contains('cancel-comment-btn')) {
        loadComments();
    }
});

// Charger les commentaires lors du chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    loadComments();
});


// Fonction pour enregistrer les paramètres du blog
function saveSettings() {
    const blogTitle = document.getElementById('blog-title').value;
    const blogDescription = document.getElementById('blog-description').value;

    // Vérifier si les champs sont vides
    if (blogTitle === '' || blogDescription === '') {
        alert('Veuillez remplir tous les champs.');
        return;
    }

    // Requête AJAX pour enregistrer les paramètres
    fetch('save_settings.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title: blogTitle, description: blogDescription })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Paramètres enregistrés avec succès.');
            
        } else {
            alert('Erreur lors de l\'enregistrement des paramètres: ' + data.error);
        }
        
    })
    .catch(error => {
        console.error('Erreur lors de l\'enregistrement des paramètres:', error);
    });
}










// script index.php
// document.addEventListener('DOMContentLoaded', function() {
//     // Bouton pour ouvrir le modal
//     const createArticleBtn = document.getElementById('create-article-btn');
//     const createArticleModal = document.getElementById('create-article-modal');
//     const closeModalBtn = document.querySelector('.close');

//     createArticleBtn.addEventListener('click', function() {
//         createArticleModal.style.display = 'block';
//     });

//     closeModalBtn.addEventListener('click', function() {
//         createArticleModal.style.display = 'none';
//     });

//     window.addEventListener('click', function(event) {
//         if (event.target === createArticleModal) {
//             createArticleModal.style.display = 'none';
//         }
//     });

//     // Formulaire pour créer un article
//     const createArticleForm = document.getElementById('create-article-form');
//     createArticleForm.addEventListener('submit', function(event) {
//         event.preventDefault();
//         const title = document.getElementById('article-title').value;
//         const content = document.getElementById('article-content').value;

//         fetch('create_article.php', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({ title, content })
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 alert('Article publié avec succès.');
//                 loadArticles();
//                 createArticleModal.style.display = 'none';
//                 document.getElementById('article-title').value = '';
//                 document.getElementById('article-content').value = '';
//             } else {
//                 alert('Erreur lors de la publication de l\'article.');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
//     });

//     // Charger les articles
//     loadArticles();
// });

// function loadArticles() {
//     fetch('load_articles.php')
//         .then(response => response.json())
//         .then(data => {
//             const articlesList = document.getElementById('articles-list');
//             articlesList.innerHTML = '';
//             data.articles.forEach(article => {
//                 const articleElement = document.createElement('div');
//                 articleElement.classList.add('article');
//                 articleElement.setAttribute('data-id', article.id_Article);
//                 articleElement.innerHTML = `
//                     <h3>${article.titre_Article}</h3>
//                     <p>${article.contenu_Article}</p>
//                     <p><small>Publié le ${article.date_Article}</small></p>
//                     <button onclick="editArticle(${article.id_Article})">Modifier</button>
//                     <button onclick="deleteArticle(${article.id_Article})">Supprimer</button>
//                     <div class="comments-container" id="comments-${article.id_Article}">
//                         <h4>Commentaires</h4>
//                         <div id="comment-list-${article.id_Article}"></div>
//                         <textarea id="comment-content-${article.id_Article}" rows="2" placeholder="Ajouter un commentaire..."></textarea>
//                         <button onclick="addComment(${article.id_Article})">Commenter</button>
//                     </div>
//                 `;
//                 articlesList.appendChild(articleElement);
//                 loadComments(article.id_Article);
//             });
//         })
//         .catch(error => console.error('Erreur lors de la récupération des articles:', error));
// }

// function editArticle(articleId) {
//     const articleElement = document.querySelector(`.article[data-id="${articleId}"]`);
//     const title = articleElement.querySelector('h3').innerText;
//     const content = articleElement.querySelector('p').innerText;

//     articleElement.innerHTML = `
//         <input type="text" class="edit-title" value="${title}">
//         <textarea class="edit-content">${content}</textarea>
//         <button onclick="saveArticle(${articleId})">Enregistrer</button>
//         <button onclick="cancelEdit(${articleId})">Annuler</button>
//     `;
// }

// function saveArticle(articleId) {
//     const articleElement = document.querySelector(`.article[data-id="${articleId}"]`);
//     const title = articleElement.querySelector('.edit-title').value;
//     const content = articleElement.querySelector('.edit-content').value;

//     fetch('edit_article.php', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify({ id: articleId, title, content })
//     })
//     .then(response => response.json())
//     .then(data => {
//         if (data.success) {
//             alert('Article modifié avec succès.');
//             loadArticles();
//         } else {
//             alert('Erreur lors de la modification de l\'article.');
//         }
//     })
//     .catch(error => console.error('Erreur:', error));
// }

// function cancelEdit(articleId) {
//     loadArticles();
// }

// function deleteArticle(articleId) {
//     if (confirm('Êtes-vous sûr de vouloir supprimer cet article ?')) {
//         fetch('delete_article.php', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({ id: articleId })
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 alert('Article supprimé avec succès.');
//                 loadArticles();
//             } else {
//                 alert('Erreur lors de la suppression de l\'article.');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
//     }
// }

// function loadComments(articleId) {
//     fetch(`load_comments.php?article_id=${articleId}`)
//         .then(response => response.json())
//         .then(data => {
//             const commentList = document.getElementById(`comment-list-${articleId}`);
//             commentList.innerHTML = '';
//             data.comments.forEach(comment => {
//                 const commentElement = document.createElement('div');
//                 commentElement.classList.add('comment');
//                 commentElement.innerHTML = `
//                     <p><strong>${comment.auteur}</strong>: ${comment.commentaire}</p>
//                     <p><small>${comment.date_commentaire}</small></p>
//                     <button onclick="deleteComment(${comment.id}, ${articleId})">Supprimer</button>
//                 `;
//                 commentList.appendChild(commentElement);
//             });
//         })
//         .catch(error => console.error('Erreur lors de la récupération des commentaires:', error));
// }

// function addComment(articleId) {
//     const commentContent = document.getElementById(`comment-content-${articleId}`).value;
//     if (commentContent.trim() === '') {
//         alert('Veuillez entrer un commentaire.');
//         return;
//     }

//     fetch('add_comment.php', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify({ article_id: articleId, commentaire: commentContent })
//     })
//     .then(response => response.json())
//     .then(data => {
//         if (data.success) {
//             alert('Commentaire ajouté avec succès.');
//             loadComments(articleId);
//             document.getElementById(`comment-content-${articleId}`).value = '';
//         } else {
//             alert('Erreur lors de l\'ajout du commentaire.');
//         }
//     })
//     .catch(error => console.error('Erreur:', error));
// }

// function deleteComment(commentId, articleId) {
//     if (confirm('Êtes-vous sûr de vouloir supprimer ce commentaire ?')) {
//         fetch('delete_comment.php', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({ id: commentId })
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 alert('Commentaire supprimé avec succès.');
//                 loadComments(articleId);
//             } else {
//                 alert('Erreur lors de la suppression du commentaire.');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
//     }
// }