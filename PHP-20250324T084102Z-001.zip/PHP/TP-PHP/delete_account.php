<?php
// Démarre une session PHP pour gérer les données de session
session_start();

// Définit le type de contenu de la réponse comme JSON
header('Content-Type: application/json');

// Informations de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

// Crée une connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifie si la connexion à la base de données a échoué
if ($conn->connect_error) {
    // Retourne une réponse JSON en cas d'échec de la connexion
    echo json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]);
    exit(); // Arrête l'exécution du script
}

// Vérifie si l'utilisateur est connecté en vérifiant les variables de session
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    // Retourne une réponse JSON si l'utilisateur n'est pas connecté
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit(); // Arrête l'exécution du script
}

// Récupère l'ID de l'utilisateur à partir de la session
$user_id = $_SESSION['user_id'];

// Requête SQL pour supprimer l'utilisateur de la base de données
// Les articles et commentaires associés seront automatiquement supprimés grâce à ON DELETE CASCADE
$sql = "DELETE FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql); // Prépare la requête SQL pour éviter les injections SQL
$stmt->bind_param("i", $user_id); // Lie le paramètre (ID de l'utilisateur) à la requête

// Exécute la requête préparée
if ($stmt->execute()) {
    // Vérifie si des lignes ont été affectées (c'est-à-dire si l'utilisateur a été supprimé)
    if ($stmt->affected_rows > 0) {
        session_destroy(); // Détruit la session après la suppression de l'utilisateur
        echo json_encode(['success' => true]); // Retourne une réponse JSON en cas de succès
    } else {
        // Retourne une réponse JSON si l'utilisateur n'a pas été trouvé
        echo json_encode(['success' => false, 'error' => 'Utilisateur non trouvé']);
    }
} else {
    // Retourne une réponse JSON en cas d'échec de l'exécution de la requête
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Ferme la requête préparée
$stmt->close();

// Ferme la connexion à la base de données
$conn->close();
?>