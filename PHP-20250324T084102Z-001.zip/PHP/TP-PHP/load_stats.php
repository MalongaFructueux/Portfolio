<?php
// load_stats.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupérer les statistiques de la base de données
$sql = "SELECT utilisateurs_connectes FROM stats LIMIT 1";
$result = $conn->query($sql);

$stats = ['utilisateurs_connectes' => 0];
if ($result && $result->num_rows > 0) {
    $stats = $result->fetch_assoc();
}

echo json_encode($stats);

$conn->close();
?>