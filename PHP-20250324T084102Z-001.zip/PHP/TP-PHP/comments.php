<?php
// Démarre une session PHP pour gérer les données de session
session_start();

// Vérifie si l'utilisateur est connecté en vérifiant la variable de session 'logged_in'
if (!isset($_SESSION['logged_in'])) {
    // Si l'utilisateur n'est pas connecté, redirige vers la page de connexion
    header('Location: login.php');
    exit(); // Arrête l'exécution du script
}

// Informations de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

// Crée une connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifie si la connexion a échoué
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); // Affiche un message d'erreur et arrête le script
}

// Requête SQL pour récupérer les commentaires récents avec le nom de l'utilisateur et le titre de l'article
$sql = "SELECT c.id_Comment, c.contenu_Comment, c.date_Comment, u.username, a.titre_Article 
        FROM comments c 
        JOIN users u ON c.user_id = u.user_id 
        JOIN articles a ON c.article_id = a.id_Article 
        ORDER BY c.date_Comment DESC"; // Trie les commentaires par date décroissante

// Exécute la requête SQL
$result = $conn->query($sql);

// Initialise un tableau pour stocker les commentaires
$comments = [];
if ($result) {
    // Récupère tous les résultats de la requête sous forme de tableau associatif
    $comments = $result->fetch_all(MYSQLI_ASSOC);
}

// Ferme la connexion à la base de données
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commentaires</title>
    <link rel="stylesheet" href="styles.css"> <!-- Lien vers la feuille de style CSS -->
    <style>
        /* Styles pour les commentaires */
        .comment {
            border-bottom: 1px solid #ccc; /* Bordure en bas de chaque commentaire */
            padding: 10px; /* Espacement interne */
            margin-bottom: 10px; /* Marge en bas */
        }
        .comment .username {
            font-weight: bold; /* Texte en gras pour le nom d'utilisateur */
            color: #2c3e50; /* Couleur du texte */
        }
        .comment .date {
            font-size: 0.9em; /* Taille de police réduite pour la date */
            color: #7f8c8d; /* Couleur du texte */
        }
        .comment .article-title {
            font-style: italic; /* Texte en italique pour le titre de l'article */
            color: #34495e; /* Couleur du texte */
        }
    </style>
    <script src="settings.js"></script> <!-- Lien vers le fichier JavaScript pour les paramètres -->
</head>
<body>
<header>
    <div class="nav-container">
        <h1 data-translate="Blog">Blog</h1>
        <nav>
            <ul>
                <!-- Liens de navigation avec des attributs data-translate pour la traduction -->
                <li><a href="index.php" data-translate="Accueil">Accueil</a></li>
                <li><a href="articles.php" data-translate="Articles">Articles</a></li>
                <li><a href="comments.php" data-translate="Commentaires admin">Commentaires admin</a></li>
                <li><a href="settings_user.php" data-translate="Paramètres">Paramètres</a></li>
                <li><a href="logout.php" data-translate="Se déconnecter">Se déconnecter</a></li>
            </ul>
        </nav>
    </div>
</header>

    <main>
        <h2>Commentaires Récents</h2>
        <div id="comments-list">
            <?php if (empty($comments)): ?>
                <!-- Affiche un message si aucun commentaire n'est trouvé -->
                <p>Aucun commentaire trouvé.</p>
            <?php else: ?>
                <!-- Boucle pour afficher chaque commentaire -->
                <?php foreach ($comments as $comment): ?>
                    <div class="comment">
                        <!-- Affiche le nom d'utilisateur -->
                        <p class="username"><?php echo htmlspecialchars($comment['username']); ?></p>
                        <!-- Affiche le contenu du commentaire -->
                        <p><?php echo htmlspecialchars($comment['contenu_Comment']); ?></p>
                        <!-- Affiche la date du commentaire -->
                        <p class="date">Publié le : <?php echo htmlspecialchars($comment['date_Comment']); ?></p>
                        <!-- Affiche le titre de l'article associé -->
                        <p class="article-title">Article : <?php echo htmlspecialchars($comment['titre_Article']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>© 2025 Malonga Fructueux, Tous droits réservés</p>
    </footer>
</body>
</html>