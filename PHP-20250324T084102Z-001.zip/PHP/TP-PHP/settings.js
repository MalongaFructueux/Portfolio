// settings.js (ajout à votre version existante)
document.addEventListener('DOMContentLoaded', function() {
    const savedLanguage = localStorage.getItem('language') || 'fr';
    const savedTheme = localStorage.getItem('theme') || 'light';
    applySettings(savedLanguage, savedTheme);

    // Ajouter un événement pour le bouton de suppression de compte
    const deleteButton = document.getElementById('delete-account-btn');
    if (deleteButton) {
        deleteButton.addEventListener('click', deleteAccount);
    }
});

function applySettings(language, theme) {
    document.documentElement.lang = language;
    translatePage(language);
    document.body.classList.remove('light', 'dark');
    document.body.classList.add(theme);
    console.log('Thème appliqué :', theme);
}

function getTranslations(language) {
    const translations = {
        fr: {
            'Blog': 'Blog',
            'Accueil': 'Accueil',
            'Articles': 'Articles',
            'Commentaires': 'Commentaires',
            'Paramètres': 'Paramètres',
            'Se déconnecter': 'Se déconnecter',
            'Settings': 'Paramètres',
            'Save': 'Enregistrer',
            'Language': 'Langue',
            'Theme': 'Thème',
            'Delete Account': 'Supprimer le compte',
            'Are you sure you want to delete your account? This action cannot be undone.': 
                'Êtes-vous sûr de vouloir supprimer votre compte ? Cette action est irréversible.'
        },
        en: {
            'Blog': 'Blog',
            'Accueil': 'Home',
            'Articles': 'Articles',
            'Commentaires': 'Comments',
            'Paramètres': 'Settings',
            'Se déconnecter': 'Log Out',
            'Settings': 'Settings',
            'Save': 'Save',
            'Language': 'Language',
            'Theme': 'Theme',
            'Delete Account': 'Delete Account',
            'Are you sure you want to delete your account? This action cannot be undone.': 
                'Are you sure you want to delete your account? This action cannot be undone.'
        }
    };
    return translations[language];
}

function translatePage(language) {
    const translations = getTranslations(language);
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[key]) {
            element.textContent = translations[key];
        }
    });
}

function deleteAccount() {
    const language = document.documentElement.lang || 'fr';
    const translations = getTranslations(language);
    const confirmMessage = translations['Are you sure you want to delete your account? This action cannot be undone.'];
    
    if (confirm(confirmMessage)) {
        fetch('settings.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete_account' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
                window.location.href = 'login.php'; // Rediriger après suppression
            } else {
                alert('Erreur : ' + data.error);
            }
        })
        .catch(error => console.error('Erreur lors de la suppression :', error));
    }
}