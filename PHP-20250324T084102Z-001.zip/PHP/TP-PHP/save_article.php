<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

try {
    $pdo = new PDO("mysql:host=localhost;dbname=dashboardblog", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $data = json_decode(file_get_contents('php://input'), true);
    $titre = $data['titre'];
    $contenu = $data['contenu'];

    $stmt = $pdo->prepare("INSERT INTO articles (titre_Article, contenu_Article) VALUES (:titre, :contenu)");
    $stmt->execute(['titre' => $titre, 'contenu' => $contenu]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>