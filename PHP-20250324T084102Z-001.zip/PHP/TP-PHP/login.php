<?php
session_start();
session_regenerate_id(true); // Nouveau session_id à chaque connexion
$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_username = $_POST['username'];
    $input_password = $_POST['password'];

    $sql = "SELECT user_id, username, password, is_admin FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $input_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($input_password, $row['password'])) {
            $_SESSION['logged_in'] = true;
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['is_admin'] = (bool)$row['is_admin'];

            // Mettre à jour last_activity dans users
            $update_sql = "UPDATE users SET last_activity = NOW() WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("i", $row['user_id']);
            $update_stmt->execute();
            $update_stmt->close();

            // Ajouter ou mettre à jour active_sessions pour cet utilisateur
            $session_id = session_id();
            $insert_session_sql = "INSERT INTO active_sessions (user_id, session_id, last_activity) 
                                   VALUES (?, ?, NOW()) 
                                   ON DUPLICATE KEY UPDATE session_id = ?, last_activity = NOW()";
            $session_stmt = $conn->prepare($insert_session_sql);
            $session_stmt->bind_param("iss", $row['user_id'], $session_id, $session_id);
            $session_stmt->execute();
            $session_stmt->close();

            if ($_SESSION['is_admin']) {
                header("Location: admin_panel.php");
            } else {
                header("Location: index.php");
            }
            exit();
        } else {
            echo "Mot de passe incorrect.";
        }
    } else {
        echo "Utilisateur non trouvé.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="login.css"> <!-- Lien vers le CSS spécifique -->
</head>
<body>
    <div id="login-page"> <!-- Encapsulation du contenu -->
        <h2>Connexion</h2>
        <?php if (isset($error_message)): ?>
            <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        <form method="POST">
            <label for="username">Nom d'utilisateur:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Mot de passe:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Se connecter</button>
        </form>
        <div class="register-link">
            <p>Pas encore de compte ? <a href="register.php">Inscrivez-vous ici</a></p>
        </div>
    </div>
    <script src="settings.js"></script>
</body>
</html>