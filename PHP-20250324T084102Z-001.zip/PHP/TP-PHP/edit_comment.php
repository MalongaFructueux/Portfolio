<?php
// Démarre la session pour accéder aux variables de session (ex. logged_in, is_admin, user_id)
session_start();

// Définit l'en-tête HTTP pour indiquer que la réponse sera au format JSON
header('Content-Type: application/json');

// Vérifie si l'utilisateur est connecté en regardant la variable de session logged_in
// Si elle n'existe pas, renvoie une erreur JSON et arrête l'exécution
if (!isset($_SESSION['logged_in'])) {
    echo json_encode(['success' => false, 'error' => 'Non autorisé']);
    exit();
}

// Crée une nouvelle connexion MySQL avec les paramètres définis (localhost, root, sans mot de passe, base dashboardblog)
$conn = new mysqli("localhost", "root", "", "dashboardblog");

// Vérifie si la connexion a échoué; si oui, renvoie une erreur JSON et arrête l'exécution
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed']);
    exit();
}

// Récupère les données envoyées en POST au format JSON (via fetch ou autre) et les décode
$data = json_decode(file_get_contents('php://input'), true);
// Extrait l'ID du commentaire à mettre à jour depuis les données JSON
$id = $data['id'];
// Extrait l'auteur du commentaire depuis les données JSON (utilisé uniquement par les admins)
$author = $data['auteur'];
// Extrait le contenu du commentaire depuis les données JSON
$content = $data['contenu'];

// Définit la requête SQL en fonction du statut de l'utilisateur
// Si l'utilisateur est admin (is_admin = true), il peut modifier l'auteur et le contenu
// Sinon, il ne peut modifier que le contenu de ses propres commentaires (vérification via user_id)
$sql = (isset($_SESSION['is_admin']) && $_SESSION['is_admin'])
    ? "UPDATE comments SET auteur_Comment = ?, contenu_Comment = ?, date_Comment = NOW() WHERE id_Comment = ?"
    : "UPDATE comments SET contenu_Comment = ?, date_Comment = NOW() WHERE id_Comment = ? AND user_id = ?";

// Prépare la requête avec des placeholders pour éviter les injections SQL
$stmt = $conn->prepare($sql);

// Lie les paramètres en fonction du statut de l'utilisateur
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    // Pour un admin : lie l'auteur, le contenu et l'ID du commentaire (3 paramètres : string, string, int)
    $stmt->bind_param("ssi", $author, $content, $id);
} else {
    // Pour un utilisateur normal : lie le contenu, l'ID du commentaire et l'ID de l'utilisateur (string, int, int)
    $stmt->bind_param("sii", $content, $id, $_SESSION['user_id']);
}

// Exécute la requête préparée
if ($stmt->execute()) {
    // Vérifie si des lignes ont été affectées (commentaire mis à jour)
    if ($stmt->affected_rows > 0) {
        // Si oui, renvoie un succès JSON
        echo json_encode(['success' => true]);
    } else {
        // Si aucune ligne n'a été affectée (commentaire non trouvé ou non autorisé), renvoie une erreur JSON
        echo json_encode(['success' => false, 'error' => 'Commentaire non trouvé ou non autorisé']);
    }
} else {
    // Si l'exécution échoue (erreur SQL), renvoie une erreur JSON avec le message d'erreur
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Ferme le statement pour libérer les ressources
$stmt->close();
// Ferme la connexion à la base de données
$conn->close();
?>