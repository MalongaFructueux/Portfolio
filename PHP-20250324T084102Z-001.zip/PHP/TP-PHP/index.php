<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog</title>
    <link rel="stylesheet" href="acceuil.css">
    <script src="settings.js"></script>
</head>
<body>
<div id="index-page">


<header>
    <div class="nav-container">
        <h1 data-translate="Blog">Blog</h1>
        <nav>
            <ul>
                <li><a href="index.php" data-translate="Accueil">Accueil</a></li>
                <li><a href="articles.php" data-translate="Articles">Articles</a></li>
                <li><a href="comments.php" data-translate="Commentaires admin" >Commentaires admin</a></li>
                <li><a href="settings_user.php" data-translate="Paramètres">Paramètres</a></li>
                <li><a href="logout.php" data-translate="Se déconnecter">Se déconnecter</a></li>
            </ul>
        </nav>
    </div>
</header>

    <main>
        <button id="create-article-btn">Créer un article</button>

        <div class="articles-container">
            <h2>Articles</h2>
            <div id="articles-list"></div>
        </div>
    </main>

    <footer>
        <p>© 2025 Malonga Fructueux, Tous droits réservés</p>
    </footer>
</div>
    <script>
        function sendHeartbeat() {
    fetch('heartbeat.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            console.warn('Heartbeat échoué');
        }
    })
    .catch(error => console.error('Erreur heartbeat :', error));
}

setInterval(sendHeartbeat, 10000);




    document.addEventListener('DOMContentLoaded', function() {
        loadArticles();

        document.getElementById('create-article-btn').addEventListener('click', function() {
            window.location.href = 'articles.php';
        });
    });

    function loadArticles() {
        fetch('load_articles.php', {
            method: 'POST', // On garde POST pour cohérence, mais GET fonctionnerait aussi
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) throw new Error('Erreur réseau');
            return response.json();
        })
        .then(data => {
            const articlesList = document.getElementById('articles-list');
            articlesList.innerHTML = '';
            if (data.success && data.articles && data.articles.length > 0) {
                data.articles.forEach(article => {
                    const articleElement = document.createElement('div');
                    articleElement.classList.add('article');
                    articleElement.setAttribute('data-id', article.id_Article);
                    articleElement.innerHTML = `
                        <h3>${article.titre_Article}</h3>
                        <p>${article.contenu_Article}</p>
                        <p><small>Publié le ${article.date_Article}</small></p>
                        <div class="comments-section">
                            <h4>Commentaires</h4>
                            <div class="comments-list" data-article-id="${article.id_Article}"></div>
                            <textarea class="comment-input" placeholder="Ajouter un commentaire..."></textarea>
                            <button onclick="addComment(${article.id_Article})">Commenter</button>
                        </div>
                    `;
                    articlesList.appendChild(articleElement);

                    // Ajouter les commentaires existants
                    const commentsList = articleElement.querySelector('.comments-list');
                    article.comments.forEach(comment => {
                        const commentElement = document.createElement('div');
                        commentElement.classList.add('comment');
                        commentElement.setAttribute('data-comment-id', comment.id_Comment);
                        commentElement.innerHTML = `
                            <p>${comment.contenu_Comment}</p>
                            <small>Publié le ${comment.date_Comment}</small>
                            <button onclick="deleteComment(${comment.id_Comment}, ${article.id_Article})">Supprimer</button>
                        `;
                        commentsList.appendChild(commentElement);
                    });
                });
            } else {
                articlesList.innerHTML = '<p>Aucun article trouvé.</p>';
            }
        })
        .catch(error => console.error('Erreur:', error));
    }

    function addComment(articleId) {
        const articleElement = document.querySelector(`.article[data-id="${articleId}"]`);
        const commentInput = articleElement.querySelector('.comment-input');
        const content = commentInput.value.trim();

        if (!content) {
            alert('Le commentaire ne peut pas être vide.');
            return;
        }

        fetch('add_comment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ article_id: articleId, content: content })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const commentsList = articleElement.querySelector('.comments-list');
                const commentElement = document.createElement('div');
                commentElement.classList.add('comment');
                commentElement.setAttribute('data-comment-id', data.comment_id);
                commentElement.innerHTML = `
                    <p>${content}</p>
                    <small>Publié le ${new Date().toLocaleString()}</small>
                    <button onclick="deleteComment(${data.comment_id}, ${articleId})">Supprimer</button>
                `;
                commentsList.appendChild(commentElement);
                commentInput.value = '';
                alert('Commentaire ajouté avec succès.');
            } else {
                alert('Erreur lors de l\'ajout : ' + data.error);
            }
        })
        .catch(error => console.error('Erreur:', error));
    }







    function deleteComment(commentId, articleId) {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce commentaire ?')) {
        fetch('delete_comment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: commentId })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur réseau : ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('Réponse de delete_comment.php:', data); // Débogage
            if (data.success) {
                const commentElement = document.querySelector(`.comment[data-comment-id="${commentId}"]`);
                commentElement.remove();
                alert('Commentaire supprimé avec succès.');
            } else {
                alert('Erreur lors de la suppression : ' + (data.error || 'Erreur inconnue'));
            }
        })
        .catch(error => {
            console.error('Erreur lors de la suppression:', error);
            alert('Erreur réseau ou serveur.');
        });
    }
}





    function editArticle(articleId) {
        window.location.href = `edit_article.php?id=${articleId}`;
    }
    </script>
</body>
</html>