<?php
// Démarre la session pour accéder aux variables de session (ex. logged_in, user_id)
session_start();

// Définit l'en-tête HTTP pour indiquer que la réponse sera au format JSON
header('Content-Type: application/json');

// Définition des variables de connexion à la base de données
$servername = "localhost"; // Nom du serveur (ici, local)
$username = "root";       // Nom d'utilisateur MySQL (par défaut root pour localhost)
$password = "";           // Mot de passe MySQL (vide ici, typique pour une config locale)
$dbname = "dashboardblog"; // Nom de la base de données à utiliser

// Crée une nouvelle connexion MySQL avec les paramètres définis
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifie si la connexion a échoué; si oui, renvoie une erreur JSON et arrête l'exécution
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

// Vérifie si l'utilisateur est connecté en regardant les variables de session
// Si logged_in ou user_id n'existent pas, renvoie une erreur JSON et arrête l'exécution
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit();
}

// Récupère les données envoyées en POST au format JSON (via fetch ou autre) et les décode
$data = json_decode(file_get_contents('php://input'), true);
// Extrait l'ID de l'article à supprimer depuis les données JSON
$article_id = $data['id'];
// Récupère l'ID de l'utilisateur actuel depuis la session
$user_id = $_SESSION['user_id'];

// Prépare une requête SQL pour supprimer un article
// Condition : l'article doit avoir l'ID spécifié ET appartenir à l'utilisateur connecté
$sql = "DELETE FROM articles WHERE id_Article = ? AND user_id = ?";
// Prépare la requête avec des placeholders pour éviter les injections SQL
$stmt = $conn->prepare($sql);
// Lie les paramètres : "ii" indique deux entiers (article_id et user_id)
$stmt->bind_param("ii", $article_id, $user_id);

// Exécute la requête préparée
// Si elle réussit (article supprimé ou aucun article correspondant), renvoie un succès JSON
if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    // Sinon, renvoie une erreur JSON avec le message d'erreur de la base de données
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Ferme le statement pour libérer les ressources
$stmt->close();
// Ferme la connexion à la base de données
$conn->close();
?>