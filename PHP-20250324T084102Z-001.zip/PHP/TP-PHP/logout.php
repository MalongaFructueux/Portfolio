<?php
session_start();

$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Log avant tout
error_log("Logout - Session ID: " . session_id());
error_log("Logout - user_id: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'non défini'));

// Supprimer l'entrée dans active_sessions
if (isset($_SESSION['user_id'])) {
    $user_id = (int)$_SESSION['user_id'];
    $delete_sql = "DELETE FROM active_sessions WHERE user_id = ?";
    $stmt = $conn->prepare($delete_sql);
    if ($stmt === false) {
        error_log("Erreur préparation requête: " . $conn->error);
        exit();
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $affected_rows = $stmt->affected_rows;
    error_log("Logout - Suppression user_id $user_id - Lignes affectées: $affected_rows");
    if ($affected_rows == 0) {
        error_log("Aucune suppression - Vérifiez si user_id $user_id existe dans active_sessions");
    }
    $stmt->close();
} else {
    error_log("Logout - Aucun user_id dans la session");
}

session_destroy();
$conn->close();
header("Location: login.php");
exit();
?>