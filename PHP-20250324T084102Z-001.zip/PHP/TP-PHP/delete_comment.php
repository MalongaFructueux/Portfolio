<?php
// Démarrer la session pour accéder aux variables de session
session_start();

// Définir le type de contenu de la réponse comme JSON
header('Content-Type: application/json');

// Connexion à la base de données MySQL
$conn = new mysqli("localhost", "root", "", "dashboardblog");

// Vérifier la connexion à la base de données
if ($conn->connect_error) {
    // Si la connexion échoue, renvoyer une réponse JSON avec un message d'erreur
    echo json_encode(['success' => false, 'error' => 'Connection failed']);
    exit();
}

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['logged_in'])) {
    // Si l'utilisateur n'est pas connecté, renvoyer une réponse JSON avec un message d'erreur
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit();
}

// Récupérer les données JSON envoyées via la méthode POST
$data = json_decode(file_get_contents('php://input'), true);
$comment_id = $data['id']; // ID du commentaire à supprimer

// Définir la requête SQL en fonction du statut de l'utilisateur
$sql = (isset($_SESSION['is_admin']) && $_SESSION['is_admin'])
    ? "DELETE FROM comments WHERE id_Comment = ?" // Si admin, peut supprimer n'importe quel commentaire
    : "DELETE FROM comments WHERE id_Comment = ? AND user_id = ?"; // Sinon, limité aux commentaires de l'utilisateur

// Préparer la requête SQL
$stmt = $conn->prepare($sql);

// Binder les paramètres en fonction du statut de l'utilisateur
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    // Si admin, lier uniquement l'ID du commentaire
    $stmt->bind_param("i", $comment_id);
} else {
    // Sinon, lier l'ID du commentaire et l'ID de l'utilisateur
    $stmt->bind_param("ii", $comment_id, $_SESSION['user_id']);
}

// Exécuter la requête SQL
if ($stmt->execute()) {
    // Vérifier si des lignes ont été affectées (supprimées)
    if ($stmt->affected_rows > 0) {
        // Si le commentaire a été supprimé avec succès, renvoyer une réponse JSON positive
        echo json_encode(['success' => true]);
    } else {
        // Si aucun commentaire n'a été trouvé ou si l'utilisateur n'est pas autorisé, renvoyer une erreur
        echo json_encode(['success' => false, 'error' => 'Commentaire non trouvé ou non autorisé']);
    }
} else {
    // Si l'exécution de la requête a échoué, renvoyer une réponse JSON avec l'erreur MySQL
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Fermer le statement et la connexion à la base de données
$stmt->close();
$conn->close();
?>