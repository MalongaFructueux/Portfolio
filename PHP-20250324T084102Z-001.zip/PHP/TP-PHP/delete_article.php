<?php
// Démarre la session pour accéder aux variables de session (ex. logged_in, user_id, is_admin)
session_start();

// Définit l'en-tête HTTP pour indiquer que la réponse sera au format JSON
header('Content-Type: application/json');

// Crée une nouvelle connexion MySQL avec les paramètres définis (localhost, root, sans mot de passe, base dashboardblog)
$conn = new mysqli("localhost", "root", "", "dashboardblog");

// Vérifie si la connexion a échoué; si oui, renvoie une erreur JSON et arrête l'exécution
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed']);
    exit();
}

// Vérifie si l'utilisateur est connecté en regardant la variable de session logged_in
// Si elle n'existe pas, renvoie une erreur JSON et arrête l'exécution
if (!isset($_SESSION['logged_in'])) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit();
}

// Récupère les données envoyées en POST au format JSON (via fetch ou autre) et les décode
$data = json_decode(file_get_contents('php://input'), true);
// Extrait l'ID de l'article à supprimer depuis les données JSON
$article_id = $data['id'];

// Définit la requête SQL en fonction du statut de l'utilisateur
// Si l'utilisateur est admin (is_admin = true), il peut supprimer n'importe quel article
// Sinon, il ne peut supprimer que ses propres articles (vérification via user_id)
$sql = (isset($_SESSION['is_admin']) && $_SESSION['is_admin'])
    ? "DELETE FROM articles WHERE id_Article = ?" // Admin : suppression sans restriction
    : "DELETE FROM articles WHERE id_Article = ? AND user_id = ?"; // Utilisateur normal : restriction par user_id

// Prépare la requête avec des placeholders pour éviter les injections SQL
$stmt = $conn->prepare($sql);

// Lie les paramètres en fonction du statut de l'utilisateur
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    // Pour un admin : lie uniquement l'ID de l'article (un seul paramètre)
    $stmt->bind_param("i", $article_id);
} else {
    // Pour un utilisateur normal : lie l'ID de l'article et l'ID de l'utilisateur (deux paramètres)
    $stmt->bind_param("ii", $article_id, $_SESSION['user_id']);
}

// Exécute la requête préparée
if ($stmt->execute()) {
    // Vérifie si des lignes ont été affectées (article supprimé)
    if ($stmt->affected_rows > 0) {
        // Si oui, renvoie un succès JSON
        echo json_encode(['success' => true]);
    } else {
        // Si aucune ligne n'a été affectée (article non trouvé ou non autorisé), renvoie une erreur JSON
        echo json_encode(['success' => false, 'error' => 'Article non trouvé ou non autorisé']);
    }
} else {
    // Si l'exécution échoue (erreur SQL), renvoie une erreur JSON avec le message d'erreur
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Ferme le statement pour libérer les ressources
$stmt->close();
// Ferme la connexion à la base de données
$conn->close();
?>