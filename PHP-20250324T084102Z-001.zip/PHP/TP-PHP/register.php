<?php
session_start();
$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Vérifier les doublons pour username
    $check_sql = "SELECT user_id FROM users WHERE username = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $username);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        echo "Erreur : Ce nom d'utilisateur est déjà pris.";
    } else {
        // Insérer l'utilisateur
        $insert_sql = "INSERT INTO users (username, password, is_admin) VALUES (?, ?, 0)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ss", $username, $password);
        if ($insert_stmt->execute()) {
            echo "Inscription réussie ! Vous pouvez vous connecter.";
        } else {
            echo "Erreur lors de l'inscription : " . $conn->error;
        }
        $insert_stmt->close();
    }

    $check_stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>
<div class="container">
    <h2>Inscription</h2>
    <form method="POST">
        <label for="username">Nom d'utilisateur (ou email):</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Mot de passe:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">S'inscrire</button>
    </form>
    <p>Déjà inscrit ? <a href="login.php">Connectez-vous</a></p>
    </div>
    <script src="settings.js"></script>
</body>
</html>