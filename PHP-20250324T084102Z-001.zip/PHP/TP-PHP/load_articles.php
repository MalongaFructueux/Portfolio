<?php
session_start();
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed']);
    exit();
}

if (!isset($_SESSION['logged_in'])) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit();
}

// Récupérer tous les articles sans filtre par user_id
$sql = "SELECT id_Article, titre_Article, contenu_Article, date_Article 
        FROM articles 
        ORDER BY date_Article DESC"; // Tri par date de création, remplacez par updated_at si nécessaire
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

$articles = [];
while ($article = $result->fetch_assoc()) {
    // Récupérer les commentaires pour chaque article
    $comment_sql = "SELECT id_Comment, contenu_Comment, date_Comment 
                    FROM comments 
                    WHERE article_id = ? 
                    ORDER BY date_Comment DESC";
    $comment_stmt = $conn->prepare($comment_sql);
    $comment_stmt->bind_param("i", $article['id_Article']);
    $comment_stmt->execute();
    $comment_result = $comment_stmt->get_result();
    
    $article['comments'] = $comment_result->fetch_all(MYSQLI_ASSOC);
    $articles[] = $article;
    
    $comment_stmt->close();
}

echo json_encode(['success' => true, 'articles' => $articles]);

$stmt->close();
$conn->close();
?>