<?php
// delete_comment.php

// Définit l'en-tête pour permettre les requêtes de n'importe quelle origine (cross-origin)
header("Access-Control-Allow-Origin: *");

// Définit les méthodes HTTP autorisées pour cette API (POST, GET, OPTIONS)
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

// Définit les en-têtes HTTP autorisés dans les requêtes (ici, Content-Type pour JSON ou formulaires)
header("Access-Control-Allow-Headers: Content-Type");

// Définition des variables de connexion à la base de données
$servername = "localhost"; // Nom du serveur (ici, local)
$username = "root";       // Nom d'utilisateur MySQL (par défaut root pour localhost)
$password = "";           // Mot de passe MySQL (vide ici, typique pour une config locale)
$dbname = "dashboardblog"; // Nom de la base de données à utiliser

// Crée une nouvelle connexion MySQL avec les paramètres définis
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifie si la connexion a échoué; si oui, arrête l'exécution avec un message d'erreur
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupère l'ID du commentaire à supprimer depuis les données envoyées via POST
$id = $_POST['id'];

// Prépare une requête SQL pour supprimer un commentaire avec l'ID spécifié
$stmt = $conn->prepare("DELETE FROM comments WHERE id = ?");

// Lie le paramètre ID à la requête préparée; "i" indique un entier
$stmt->bind_param("i", $id);

// Exécute la requête préparée
if ($stmt->execute()) {
    // Si la suppression réussit, renvoie un succès au format JSON
    echo json_encode(['success' => true]);
} else {
    // Si la suppression échoue, renvoie une erreur JSON avec le message d'erreur de la base de données
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Ferme le statement pour libérer les ressources
$stmt->close();
// Ferme la connexion à la base de données
$conn->close();
?>