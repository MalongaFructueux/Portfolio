<?php

if (isset($_GET['sid'])) {
    session_id($_GET['sid']);
}


session_start();
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Log de la session
error_log("get_stats - Session ID: " . session_id());
error_log("get_stats - is_admin: " . (isset($_SESSION['is_admin']) ? var_export($_SESSION['is_admin'], true) : 'non défini'));

// if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
//     error_log("get_stats - Accès non autorisé");
//     echo json_encode(['error' => 'Non autorisé']);
//     exit();
// }

$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    echo json_encode(['error' => 'Connection failed']);
    exit();
}

// Purger les sessions inactives
$purge_sql = "DELETE FROM active_sessions WHERE last_activity < NOW() - INTERVAL 15 MINUTE";
$conn->query($purge_sql);
error_log("Purge sessions inactives - Lignes supprimées: " . $conn->affected_rows);

// Compter les sessions actives
$sql_connected = "SELECT COUNT(DISTINCT user_id) as connected FROM active_sessions";
$connected_result = $conn->query($sql_connected);
$connected_count = $connected_result->fetch_assoc()['connected'] ?? 0;

$sql_users = "SELECT COUNT(*) as users FROM users";
$users_result = $conn->query($sql_users);
$users_count = $users_result->fetch_assoc()['users'] ?? 0;

$sql_articles = "SELECT COUNT(*) as articles FROM articles";
$articles_result = $conn->query($sql_articles);
$articles_count = $articles_result->fetch_assoc()['articles'] ?? 0;

$sql_comments = "SELECT COUNT(*) as comments FROM comments";
$comments_result = $conn->query($sql_comments);
$comments_count = $comments_result->fetch_assoc()['comments'] ?? 0;

error_log("Stats - Connected: $connected_count, Users: $users_count, Articles: $articles_count, Comments: $comments_count");

echo json_encode([
    'connected' => $connected_count,
    'users' => $users_count,
    'articles' => $articles_count,
    'comments' => $comments_count
]);

$conn->close();
?>