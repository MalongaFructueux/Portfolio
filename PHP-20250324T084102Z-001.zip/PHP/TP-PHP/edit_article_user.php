<?php
// Démarre la session pour accéder aux variables de session (ex. logged_in, user_id)
session_start();

// Définit l'en-tête HTTP pour indiquer que la réponse sera au format JSON
header('Content-Type: application/json');

// Crée une nouvelle connexion MySQL avec les paramètres définis (localhost, root, sans mot de passe, base dashboardblog)
$conn = new mysqli("localhost", "root", "", "dashboardblog");

// Vérifie si la connexion a échoué; si oui, renvoie une erreur JSON et arrête l'exécution
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed']);
    exit();
}

// Vérifie si l'utilisateur est connecté en regardant les variables de session
// Si logged_in ou user_id n'existent pas, renvoie une erreur JSON et arrête l'exécution
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit();
}

// Récupère les données envoyées en POST au format JSON (via fetch ou autre) et les décode
$data = json_decode(file_get_contents('php://input'), true);
// Extrait l'ID de l'article à mettre à jour depuis les données JSON
$article_id = $data['id'];
// Extrait et sécurise le titre de l'article avec htmlspecialchars pour éviter les attaques XSS
$title = htmlspecialchars($data['title']);
// Extrait et sécurise le contenu de l'article avec htmlspecialchars
$content = htmlspecialchars($data['content']);
// Extrait la date de l'article depuis les données JSON (non sécurisée ici, supposée valide)
$date = $data['date'];
// Récupère l'ID de l'utilisateur actuel depuis la session
$user_id = $_SESSION['user_id'];

// Prépare une requête SQL pour mettre à jour un article
// Met à jour titre, contenu, date, et ajoute un timestamp updated_at
// Condition : l'article doit avoir l'ID spécifié ET appartenir à l'utilisateur connecté
$sql = "UPDATE articles SET titre_Article = ?, contenu_Article = ?, date_Article = ?, updated_at = NOW() 
        WHERE id_Article = ? AND user_id = ?";
// Prépare la requête avec des placeholders pour éviter les injections SQL
$stmt = $conn->prepare($sql);
// Lie les paramètres : "sssii" indique 3 chaînes (title, content, date) et 2 entiers (article_id, user_id)
$stmt->bind_param("sssii", $title, $content, $date, $article_id, $user_id);

// Exécute la requête préparée
if ($stmt->execute()) {
    // Si la mise à jour réussit, renvoie un succès JSON
    echo json_encode(['success' => true]);
} else {
    // Si la mise à jour échoue, renvoie une erreur JSON avec le message d'erreur de la base de données
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Ferme le statement pour libérer les ressources
$stmt->close();
// Ferme la connexion à la base de données
$conn->close();
?>