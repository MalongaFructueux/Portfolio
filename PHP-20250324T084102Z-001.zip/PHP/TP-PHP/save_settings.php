<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

$response = ['success' => false, 'error' => '']; // Réponse par défaut

try {
    // Connexion à la base de données avec gestion d'erreur
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        throw new Exception('Erreur de connexion : ' . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4"); // Gérer l'encodage des caractères

    // Récupération des données JSON
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    // Vérification des erreurs JSON
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Données JSON invalides : ' . json_last_error_msg());
    }

    // Vérification des champs
    if (!isset($data['title']) || !isset($data['description'])) {
        throw new Exception('Champs requis manquants.');
    }

    $title = htmlspecialchars(trim($data['title']));
    $description = htmlspecialchars(trim($data['description']));

    if (empty($title) || empty($description)) {
        throw new Exception('Les champs ne peuvent pas être vides.');
    }

    // Requête SQL sécurisée
    $sql = "INSERT INTO parametre (titre_blog, description_blog) VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE titre_blog = VALUES(titre_blog), description_blog = VALUES(description_blog)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Erreur de préparation SQL : ' . $conn->error);
    }

    $stmt->bind_param("ss", $title, $description);
    
    if (!$stmt->execute()) {
        throw new Exception('Erreur d\'exécution SQL : ' . $stmt->error);
    }

    $response['success'] = true;

} catch (Exception $e) {
    $response['error'] = $e->getMessage();
}

// Retourner la réponse en JSON
echo json_encode($response);

// Fermer la connexion
if (isset($stmt)) {
    $stmt->close();
}
$conn->close();
?>
