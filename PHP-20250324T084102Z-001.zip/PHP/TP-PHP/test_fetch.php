<?php
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_id'] = 1; // Simuler un utilisateur connecté
$data = json_encode([]);
$ch = curl_init('http://localhost/TP-PHP/load_articles_users.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$response = curl_exec($ch);
curl_close($ch);
echo $response;
?>