<?php
session_start();
$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérifier si l'utilisateur est un admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php");
    exit();
}

// Traitement de la suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = $_POST['username'];

    // Vérifier si l'utilisateur existe
    $check_sql = "SELECT user_id FROM users WHERE username = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $username);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['user_id'];

        // Supprimer de active_sessions
        $delete_session_sql = "DELETE FROM active_sessions WHERE user_id = ?";
        $session_stmt = $conn->prepare($delete_session_sql);
        $session_stmt->bind_param("i", $user_id);
        $session_stmt->execute();
        $session_stmt->close();

        // Supprimer de users
        $delete_user_sql = "DELETE FROM users WHERE user_id = ?";
        $user_stmt = $conn->prepare($delete_user_sql);
        $user_stmt->bind_param("i", $user_id);
        $user_stmt->execute();
        $affected_rows = $user_stmt->affected_rows;
        $user_stmt->close();

        if ($affected_rows > 0) {
            $message = "Compte '$username' supprimé avec succès.";
        } else {
            $message = "Erreur lors de la suppression du compte.";
        }
    } else {
        $message = "Utilisateur '$username' non trouvé.";
    }

    $check_stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paramètres - Suppression de Compte</title>
    <link rel="stylesheet" href="settings.css"> <!-- Lien vers le CSS spécifique -->
</head>
<body>
    <div id="delete-user-page"> <!-- Encapsulation du contenu -->
        <h2>Supprimer un Compte Utilisateur</h2>
        <?php if (isset($message)): ?>
            <p class="message <?php echo strpos($message, 'succès') !== false ? 'success' : 'error'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </p>
        <?php endif; ?>
        <form method="POST" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce compte ? Cette action est irréversible.');">
            <label for="username">Nom d'utilisateur :</label>
            <input type="text" id="username" name="username" required placeholder="Entrez le nom d'utilisateur">
            <button type="submit">Supprimer le compte</button>
        </form>
        <div class="back-link">
            <a href="admin_panel.php">Retour au tableau de bord</a>
        </div>
    </div>
    <script src="settings.js"></script>
</body>
</html>