<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]));
}

$id = $_GET['id'];
$sql = "SELECT id, auteur, commentaire, date_commentaire FROM comments WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $comment = $result->fetch_assoc();
    echo json_encode(['success' => true, 'comment' => $comment]);
} else {
    echo json_encode(['success' => false, 'error' => 'Comment not found']);
}

$stmt->close();
$conn->close();
?>