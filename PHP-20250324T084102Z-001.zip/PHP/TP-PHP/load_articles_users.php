<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboardblog";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

if (!isset($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT id_Article, titre_Article, contenu_Article, date_Article 
        FROM articles 
        WHERE user_id = ? 
        ORDER BY date_Article DESC"; // Tri par date de création la plus récente
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$articles = [];
if ($result) {
    $articles = $result->fetch_all(MYSQLI_ASSOC);
}

echo json_encode(['success' => true, 'articles' => $articles]);

$stmt->close();
$conn->close();
?>