-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 23 mars 2025 à 14:36
-- Version du serveur : 8.2.0
-- Version de PHP : 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `dashboardblog`
--

-- --------------------------------------------------------

--
-- Structure de la table `active_sessions`
--

DROP TABLE IF EXISTS `active_sessions`;
CREATE TABLE IF NOT EXISTS `active_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `session_id` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `last_activity` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=493 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `active_sessions`
--

INSERT INTO `active_sessions` (`id`, `user_id`, `session_id`, `last_activity`) VALUES
(479, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:30:17'),
(478, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:29:23'),
(477, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:29:16'),
(476, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:28:23'),
(474, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:27:23'),
(472, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:27:12'),
(470, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:27:02'),
(468, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:52'),
(466, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:42'),
(463, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:23'),
(458, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:02'),
(453, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:34'),
(452, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:23'),
(451, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:13'),
(450, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:08'),
(447, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:53'),
(446, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:45'),
(444, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:33'),
(484, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:32:23'),
(485, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:33:20'),
(483, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:32:19'),
(482, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:31:23'),
(481, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:31:18'),
(464, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:32'),
(460, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:12'),
(456, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:52'),
(455, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:44'),
(435, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:23:42'),
(433, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:23:18'),
(432, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:23:08'),
(434, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:23:37'),
(431, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:22:58'),
(430, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:22:48'),
(429, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:22:38'),
(428, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:22:28'),
(427, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:22:18'),
(492, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:36:23'),
(438, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:03'),
(490, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:35:23'),
(480, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:30:23'),
(442, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:23'),
(441, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:15'),
(487, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:34:21'),
(486, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:33:23'),
(489, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:35:22'),
(488, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:34:23'),
(491, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:36:23'),
(425, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:21:23'),
(426, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:22:13'),
(436, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:23:53'),
(437, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:23:55'),
(439, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:05'),
(440, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:12'),
(443, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:25'),
(445, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:43'),
(448, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:24:54'),
(449, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:05'),
(454, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:42'),
(457, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:25:54'),
(459, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:04'),
(461, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:14'),
(462, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:22'),
(465, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:34'),
(467, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:44'),
(469, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:26:54'),
(471, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:27:04'),
(473, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:27:14'),
(475, 5, 'njfmos23esh7a2ieee1vpvvu5v', '2025-03-23 15:28:15');

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id_Article` int NOT NULL AUTO_INCREMENT,
  `titre_Article` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_Article` date NOT NULL,
  `contenu_Article` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_Article`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id_Article`, `titre_Article`, `date_Article`, `contenu_Article`, `user_id`, `updated_at`) VALUES
(91, 'fzgzr', '2025-03-22', 'gzrgzr', 0, '2025-03-22 21:19:49'),
(92, 'fzgzr', '2025-03-22', 'gzrgzr', 0, '2025-03-22 21:19:49'),
(94, 'OOOO', '2025-03-22', 'OOOOO', NULL, '2025-03-22 21:19:49'),
(95, 'VVVV', '2025-03-22', 'VVVV', NULL, '2025-03-22 21:19:49'),
(96, 'AZ', '2025-03-22', 'AZ', NULL, '2025-03-22 21:19:49'),
(117, 'ZAMBR', '2025-03-23', 'NYAMBI', 6, '2025-03-22 23:08:48'),
(103, 'AZ', '2025-03-22', 'AZ', 2, '2025-03-22 21:19:49'),
(106, 'TEHETHET', '2025-03-22', 'ETHTH', 2, '2025-03-22 21:19:49'),
(124, 'c&#039;est l&#039;artcile 2 de YSOS', '2025-03-23', 'YSOS ARTCILE 2', 9, '2025-03-23 13:48:19');

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id_Comment` int NOT NULL AUTO_INCREMENT,
  `article_id` int NOT NULL,
  `user_id` int NOT NULL,
  `contenu_Comment` text COLLATE utf8mb4_general_ci NOT NULL,
  `date_Comment` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `auteur_Comment` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_Comment`),
  KEY `article_id` (`article_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`id_Comment`, `article_id`, `user_id`, `contenu_Comment`, `date_Comment`, `auteur_Comment`) VALUES
(3, 115, 1, 'FIREBEEEEEAAAT', '2025-03-22 23:10:22', ''),
(4, 88, 1, 'fff', '2025-03-23 08:55:24', ''),
(15, 90, 10, 'Je suis zeno', '2025-03-23 13:46:41', ''),
(11, 104, 2, 'un voyou', '2025-03-23 09:04:13', ''),
(14, 93, 5, 'toi lele lolo', '2025-03-23 14:25:08', ''),
(9, 89, 2, 'deux voyous bien eduquéé', '2025-03-23 14:23:37', ''),
(17, 90, 9, 'Je suis Ysos le goat', '2025-03-23 13:57:35', '');

-- --------------------------------------------------------

--
-- Structure de la table `connected_users`
--

DROP TABLE IF EXISTS `connected_users`;
CREATE TABLE IF NOT EXISTS `connected_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `count` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `connected_users`
--

INSERT INTO `connected_users` (`id`, `count`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `parametre`
--

DROP TABLE IF EXISTS `parametre`;
CREATE TABLE IF NOT EXISTS `parametre` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titre_blog` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description_blog` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `parametre`
--

INSERT INTO `parametre` (`id`, `titre_blog`, `description_blog`) VALUES
(13, '0', '0'),
(12, '0', '0'),
(14, 'zrhzrhzt', 'zthztth'),
(15, 'AZERR', 'ZERETET'),
(16, 'QSQ', 'QSQ'),
(17, 'Big aka akafor', 'Himra');

-- --------------------------------------------------------

--
-- Structure de la table `stats`
--

DROP TABLE IF EXISTS `stats`;
CREATE TABLE IF NOT EXISTS `stats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilisateurs_connectes` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_admin` tinyint(1) DEFAULT '0',
  `last_activity` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `created_at`, `is_admin`, `last_activity`) VALUES
(9, 'Ysos', '$2y$10$4b4EnhCsVODuRs42MQ4UHutOqOkAd/O4DmiUrhlET04vsAVvyi3BG', '', '2025-03-23 14:46:13', 0, '2025-03-23 14:58:49'),
(5, 'root_ultime', '$2y$10$jFqncDnHwx65M8U6NhjNgudL9WueRT5QGuQgGgjV41sg1TLFMJoUu', '', '2025-03-22 23:41:49', 1, '2025-03-23 14:59:35'),
(6, 'ZERO', '$2y$10$HnYOkBM75RM8kiLGgJtt1eEU0XSVH5AgVnpbojVwqgthyposc9nnC', 'book@gmail.com', '2025-03-23 00:08:12', 0, '2025-03-23 12:36:27'),
(8, 'AZERTY', '$2y$10$9l98iHCaLTqnUAUV0w9vwevSI8lsic2PGJNZhL/P62pyhi2x/9W12', '', '2025-03-23 10:43:20', 0, '2025-03-23 12:13:49'),
(10, 'Zeno', '$2y$10$cVERoyfT3uXmY25YnIRwv.LexV3A8Lrch5y4wmarJdw6E0mlI7oTC', '', '2025-03-23 14:46:25', 0, '2025-03-23 14:49:03');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
