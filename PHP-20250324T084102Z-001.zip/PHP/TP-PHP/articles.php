<?php
// Démarre une session PHP pour gérer les données de session
session_start();

// Vérifie si l'utilisateur est connecté en vérifiant la variable de session 'logged_in'
if (!isset($_SESSION['logged_in'])) {
    // Si l'utilisateur n'est pas connecté, redirige vers la page de connexion
    header('Location: login.php');
    exit(); // Arrête l'exécution du script
}

// Récupère l'ID de l'utilisateur à partir de la session
$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un article</title>
    <link rel="stylesheet" href="articles.css"> <!-- Lien vers la feuille de style CSS -->
    <script src="settings.js"></script> <!-- Lien vers le fichier JavaScript pour les paramètres -->
</head>
<body>
    <header>
        <div class="nav-container">
            <h1>Blog</h1>
            <nav>
                <ul>
                    <!-- Liens de navigation avec des attributs data-translate pour la traduction -->
                    <li><a href="index.php" data-translate="Accueil">Accueil</a></li>
                    <li><a href="articles.php" data-translate="Articles">Articles</a></li>
                    <li><a href="comments.php" data-translate="Commentaires admin">Commentaires admin</a></li>
                    <li><a href="settings_user.php" data-translate="Paramètres">Paramètres</a></li>
                    <li><a href="logout.php" data-translate="Se déconnecter">Se déconnecter</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <h2>Créer un article</h2>
        <!-- Formulaire pour créer un nouvel article -->
        <form id="create-article-form">
            <label for="article-title">Titre de l'article:</label>
            <input type="text" id="article-title" name="title" required>
            <label for="article-content">Contenu de l'article:</label>
            <textarea id="article-content" name="content" rows="4" required></textarea>
            <button type="submit">Publier</button>
        </form>

        <div class="articles-container">
            <h2>Articles</h2>
            <!-- Barre de recherche pour filtrer les articles -->
            <input type="text" id="search-bar" placeholder="Rechercher par titre, date ou contenu...">
            <div id="articles-list"></div> <!-- Conteneur pour afficher les articles -->
        </div>
    </main>

    <footer>
        <p>© 2025 Malonga Fructueux, Tous droits réservés</p>
    </footer>

    <script>
        let allArticles = []; // Stocke tous les articles pour la recherche

        // Fonction pour charger les articles depuis le serveur
        function loadArticles() {
            fetch('load_articles_users.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ user_id: <?php echo json_encode($user_id); ?> })
            })
            .then(response => {
                if (!response.ok) throw new Error('Erreur réseau');
                return response.json();
            })
            .then(data => {
                console.log('Données reçues:', data);
                const articlesList = document.getElementById('articles-list');
                articlesList.innerHTML = '';
                if (data.success && data.articles && data.articles.length > 0) {
                    allArticles = data.articles; // Stocke les articles pour la recherche
                    displayArticles(allArticles); // Affiche les articles
                } else {
                    articlesList.innerHTML = '<p>Aucun article trouvé pour cet utilisateur.</p>';
                }
            })
            .catch(error => console.error('Erreur:', error));
        }

        // Fonction pour afficher les articles dans le conteneur
        function displayArticles(articles) {
            const articlesList = document.getElementById('articles-list');
            articlesList.innerHTML = '';
            articles.forEach(article => {
                const articleElement = document.createElement('div');
                articleElement.classList.add('article');
                articleElement.setAttribute('data-id', article.id_Article);
                articleElement.setAttribute('data-date', article.date_Article);
                articleElement.innerHTML = `
                    <h3>${article.titre_Article}</h3>
                    <p>${article.contenu_Article}</p>
                    <p class="date"><small>Publié le : ${article.date_Article}</small></p>
                    <button class="edit-btn" onclick="editArticle(${article.id_Article})">Modifier</button>
                    <button class="delete-btn" onclick="deleteArticle(${article.id_Article})">Supprimer</button>
                `;
                articlesList.appendChild(articleElement);
            });
        }

        // Gestion de la soumission du formulaire de création d'article
        document.getElementById('create-article-form').addEventListener('submit', function(event) {
            event.preventDefault();
            const title = document.getElementById('article-title').value;
            const content = document.getElementById('article-content').value;

            fetch('create_article.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ title, content })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Article publié avec succès.');
                    document.getElementById('create-article-form').reset();
                    loadArticles(); // Recharge les articles après la publication
                } else {
                    alert('Erreur lors de la publication : ' + data.error);
                }
            })
            .catch(error => console.error('Erreur:', error));
        });

        // Gestion de la barre de recherche
        document.getElementById('search-bar').addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const filteredArticles = allArticles.filter(article => 
                article.titre_Article.toLowerCase().includes(searchTerm) ||
                article.contenu_Article.toLowerCase().includes(searchTerm) ||
                article.date_Article.toLowerCase().includes(searchTerm)
            );
            displayArticles(filteredArticles);
        });

        // Fonction pour éditer un article
        function editArticle(articleId) {
            const articleElement = document.querySelector(`.article[data-id="${articleId}"]`);
            const title = articleElement.querySelector('h3').innerText;
            const content = articleElement.querySelector('p:not(.date)').innerText;
            const date = articleElement.getAttribute('data-date');

            articleElement.innerHTML = `
                <input type="text" class="edit-title" value="${title}">
                <textarea class="edit-content">${content}</textarea>
                <button onclick="saveArticle(${articleId}, '${date}')">Enregistrer</button>
                <button onclick="cancelEdit(${articleId}, '${title}', '${content}', '${date}')">Annuler</button>
            `;
        }

        // Fonction pour sauvegarder les modifications d'un article
        function saveArticle(articleId, originalDate) {
            const articleElement = document.querySelector(`.article[data-id="${articleId}"]`);
            const newTitle = articleElement.querySelector('.edit-title').value;
            const newContent = articleElement.querySelector('.edit-content').value;
            const date = originalDate;

            fetch('edit_article_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: articleId, title: newTitle, content: newContent, date: date })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    articleElement.innerHTML = `
                        <h3>${newTitle}</h3>
                        <p>${newContent}</p>
                        <p class="date"><small>Publié le : ${date}</small></p>
                        <button onclick="editArticle(${articleId})">Modifier</button>
                        <button onclick="deleteArticle(${articleId})">Supprimer</button>
                    `;
                    articleElement.setAttribute('data-date', date);
                    alert('Article modifié avec succès.');
                    loadArticles(); // Recharge les articles après la modification
                } else {
                    alert('Erreur lors de la modification : ' + data.error);
                }
            })
            .catch(error => console.error('Erreur:', error));
        }

        // Fonction pour annuler l'édition d'un article
        function cancelEdit(articleId, originalTitle, originalContent, originalDate) {
            const articleElement = document.querySelector(`.article[data-id="${articleId}"]`);
            articleElement.innerHTML = `
                <h3>${originalTitle}</h3>
                <p>${originalContent}</p>
                <p class="date"><small>Publié le : ${originalDate}</small></p>
                <button onclick="editArticle(${articleId})">Modifier</button>
                <button onclick="deleteArticle(${articleId})">Supprimer</button>
            `;
            articleElement.setAttribute('data-date', originalDate);
        }

        // Fonction pour supprimer un article
        function deleteArticle(articleId) {
            if (confirm('Êtes-vous sûr de vouloir supprimer cet article ?')) {
                fetch('delete_article_user.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: articleId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector(`.article[data-id="${articleId}"]`).remove();
                        alert('Article supprimé avec succès.');
                        loadArticles(); // Recharge les articles après la suppression
                    } else {
                        alert('Erreur lors de la suppression : ' + data.error);
                    }
                })
                .catch(error => console.error('Erreur:', error));
            }
        }

        // Charge les articles lorsque la page est entièrement chargée
        document.addEventListener('DOMContentLoaded', loadArticles);
    </script>
</body>
</html>