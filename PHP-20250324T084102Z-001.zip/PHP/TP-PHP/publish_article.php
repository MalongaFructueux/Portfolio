<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Non autorisé']);
    exit();
}

$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$title = $data['titre'];
$content = $data['contenu'];
$user_id = $data['user_id'];

$sql = "INSERT INTO articles (titre_Article, contenu_Article, date_Article, user_id) VALUES (?, ?, NOW(), ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $title, $content, $user_id);

if ($stmt->execute()) {
    $new_id = $conn->insert_id;
    echo json_encode(['success' => true, 'id' => $new_id]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$stmt->close();
$conn->close();
?>