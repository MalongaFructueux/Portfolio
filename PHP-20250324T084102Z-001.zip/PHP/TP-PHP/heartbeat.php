<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false]);
    exit();
}

$conn = new mysqli("localhost", "root", "", "dashboardblog");
if ($conn->connect_error) {
    echo json_encode(['success' => false]);
    exit();
}

$user_id = $_SESSION['user_id'];
$session_id = session_id();
$sql = "INSERT INTO active_sessions (user_id, session_id, last_activity) 
        VALUES (?, ?, NOW()) 
        ON DUPLICATE KEY UPDATE session_id = ?, last_activity = NOW()";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iss", $user_id, $session_id, $session_id);
$stmt->execute();
$stmt->close();

echo json_encode(['success' => true]);
$conn->close();
?>