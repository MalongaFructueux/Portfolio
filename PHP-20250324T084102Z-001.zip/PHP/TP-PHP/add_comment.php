<?php
// Démarrage de la session pour accéder aux variables de session
session_start();

// Définition du type de contenu de la réponse comme JSON
header('Content-Type: application/json');

// Connexion à la base de données MySQL
$conn = new mysqli("localhost", "root", "", "dashboardblog");

// Vérification de la connexion à la base de données
if ($conn->connect_error) {
    // Si la connexion échoue, renvoie une réponse JSON avec un message d'erreur
    echo json_encode(['success' => false, 'error' => 'Connection failed']);
    exit();
}

// Vérification si l'utilisateur est connecté et si son ID est défini
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    // Si l'utilisateur n'est pas connecté, renvoie une réponse JSON avec un message d'erreur
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté']);
    exit();
}

// Récupération des données JSON envoyées via la méthode POST
$data = json_decode(file_get_contents('php://input'), true);

// Extraction des données nécessaires
$article_id = $data['article_id']; // ID de l'article auquel le commentaire est associé
$content = htmlspecialchars($data['content']); // Contenu du commentaire (nettoyé pour éviter les injections HTML)
$user_id = $_SESSION['user_id']; // ID de l'utilisateur connecté

// Préparation de la requête SQL pour insérer un nouveau commentaire
$sql = "INSERT INTO comments (article_id, user_id, contenu_Comment, date_Comment) 
        VALUES (?, ?, ?, NOW())";

// Préparation de la requête avec des paramètres pour éviter les injections SQL
$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $article_id, $user_id, $content); // Liaison des paramètres

// Exécution de la requête SQL
if ($stmt->execute()) {
    // Si l'insertion est réussie, renvoie une réponse JSON avec l'ID du commentaire inséré
    echo json_encode(['success' => true, 'comment_id' => $stmt->insert_id]);
} else {
    // Si l'insertion échoue, renvoie une réponse JSON avec un message d'erreur
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

// Fermeture du statement et de la connexion à la base de données
$stmt->close();
$conn->close();
?>